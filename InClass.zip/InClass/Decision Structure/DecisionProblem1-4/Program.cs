﻿namespace DecisionProblem1_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            double num1,
                    tax;

            // input number
            Console.Write("Enter taxable income: ");
            num1 = double.Parse(Console.ReadLine());

            // determine tax due
            if (num1 <= 50000)
            {
                tax = num1 * 0.05;
            }
            else if (num1 <= 100000)
            {
                tax = 2500 + ((num1 - 50000) * 0.07);
            }
            else
            {
                tax = 6000 + (0.09 * (num1 - 100000));
            }
            
            // display results
            Console.WriteLine($"The tax on {num1:c} is {tax:c}");
        }
    }
}