﻿/*
 * Purpose: Determine the highest number from 3 whole numbers
 * Input: num1, num2, num3
 * Output: Highest
 * Author: Reonel Duque
 * Date: September 14, 2022
*/

namespace DecisionsExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int num1,
                num2,
                num3,
                greater;

            //input three numbers
            Console.Write("Enter the first whole number: ");
            num1 = int.Parse(Console.ReadLine());

            Console.Write("Enter the second whole number: ");
            num2 = int.Parse(Console.ReadLine());

            Console.Write("Enter the third whole number: ");
            num3 = int.Parse(Console.ReadLine());

            //determine the highest
            // compare number 1 to number 2
            if (num1 > num2)
            {
                greater = num1;
            }

            else
            {
                greater = num2;
            }

            // compare the third number to the greater number obtained from previous step
            if (num3 > greater)
            {
                greater = num3;
            }

            // display the highest number
            Console.Write($"The highest number is {greater}");

            Console.ReadLine();

        }
    }
}