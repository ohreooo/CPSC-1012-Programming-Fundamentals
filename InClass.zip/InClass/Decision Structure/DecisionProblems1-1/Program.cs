﻿/*
 * Purpose: Write a program that will prompt for a number and display “positive” if it is greater than zero,
            “negative” if it is less than zero, and “zero” if it is equal to zero.
 * Input: num1
 * Output: If num1 is positive, negative, or equal to 0
 * Author: Reonel Duque
 * Date: September 14, 2022
 */
namespace DecisionProblems1_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            double num1;
            string message;

            //input a number
            Console.Write("Enter a number: ");
            num1 = double.Parse(Console.ReadLine());

            //compare if it is zero
            if (num1 !=0)
            {
                //compare if it is positive or negative if it is non-zero
                if (num1 > 0)
                {
                    message = "positive";
                }
                else
                {
                    message = "negative";
                }
            }
            else
            {
                message = "zero";
            }

            //display results
            Console.WriteLine($"The number, {num1}, is {message}");
        }
    }
}