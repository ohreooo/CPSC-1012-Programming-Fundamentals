﻿/*
 Purpose: Computes the area and volume of a given radius and length

 Input: Radius and Length

 Output: Area and Volume of a cylinder

 Written by: Reonel Duque

 Written for: Allan Anderson

 Section: A02

 Date: September 9, 2022
*/


namespace Cylinder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            double area,
                radius,
                length,
                volume;

            //input radius and length
            Console.Write("Enter the radius of a cylinder: ");
            radius = double.Parse(Console.ReadLine());
            Console.Write("Enter the length of a cylinder: ");
            length = double.Parse(Console.ReadLine());
            
            //calculate the area of a cylinder
            area = (2 * Math.PI ) * ((radius * length) + (radius * radius));

            //calculate the volume of a cylinder
            volume = Math.PI * (radius * radius) * (length);

            //display results
            Console.WriteLine($"The area is {area:f4}");
            Console.WriteLine($"The volume is {volume:f4}");

            //keep the console open
            Console.ReadLine();
        }
    }
}