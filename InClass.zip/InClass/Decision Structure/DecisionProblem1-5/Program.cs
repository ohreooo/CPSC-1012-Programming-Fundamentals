﻿using System.Threading.Tasks.Sources;

namespace DecisionProblem1_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string runner1,
                runner2,
                runner3,
                firstPlace,
                secondPlace,
                thirdPlace;
            int time1,
                time2,
                time3,
                gold,
                silver,
                bronze;
                
               
            Console.Write("Enter name of runner 1: ");
            runner1 = Console.ReadLine();
            Console.Write("Enter finish time in minutes: ");
            time1 = int.Parse(Console.ReadLine());
            Console.Write("Enter name of runner 2: ");
            runner2 = Console.ReadLine();
            Console.Write("Enter finish time in minutes: ");
            time2 = int.Parse(Console.ReadLine());

            Console.Write("Enter name of runner 3: ");
            runner3 = Console.ReadLine();
            Console.Write("Enter finish time in minutes: ");
            time3 = int.Parse(Console.ReadLine());

            /*if (time1 > time2 && time2 > time3)
            {
                Console.WriteLine($"1st place: {runner3} at {time3} minutes");
                Console.WriteLine($"2nd place: {runner2} at {time2} minutes");
                Console.WriteLine($"3rd place: {runner1} at {time1} minutes");
            }
            else if (time1 > time3 && time3 > time2)
            {
                Console.WriteLine($"1st place: {runner2} at {time2} minutes");
                Console.WriteLine($"2nd place: {runner3} at {time3} minutes");
                Console.WriteLine($"1st place: {runner1} at {time1} minutes");
            }
            else if (time2 > time1 && time1 > time3)
            {
                Console.WriteLine($"1st place: {runner3} at {time3} minutes");
                Console.WriteLine($"2nd place: {runner1} at {time1} minutes");
                Console.WriteLine($"3rd place: {runner2} at {time2} minutes");
            }
            else if (time2 > time3 && time3 > time1)
            {
                Console.WriteLine($"1st place: {runner1} at {time1} minutes");
                Console.WriteLine($"2nd place: {runner3} at {time3} minutes");
                Console.WriteLine($"3rd place: {runner2} at {time2} minutes");
            }
            else if (time3 > time1 && time1 > time2)
            {
                Console.WriteLine($"1st place: {runner2} at {time2} minutes");
                Console.WriteLine($"2nd place: {runner1} at {time1} minutes");
                Console.WriteLine($"3rd place: {runner3} at {time3} minutes");
            }
            else
            {
                Console.WriteLine($"1st place: {runner1} at {time1} minutes");
                Console.WriteLine($"1st place: {runner2} at {time2} minutes");
                Console.WriteLine($"1st place: {runner3} at {time3} minutes");
            }*/
            // PROPER WAY
            if (time1 < time2)
            {
                gold = time1;
                silver = time2;

                firstPlace = runner1;
                secondPlace = runner2;
            }
            else
            {
                gold = time2;
                silver = time1;

                firstPlace = runner2;
                secondPlace = runner1;
            }
            if (time3 < gold)
            {
                bronze = silver;
                silver = gold;
                gold = time3;

                thirdPlace = secondPlace;
                secondPlace = firstPlace;
                firstPlace = runner3;
            }
            else if (time3 < silver)
            {
                bronze = silver;
                silver = time3;

                thirdPlace = secondPlace;
                secondPlace = runner3;
            }
            else
            {
                bronze = time3;

                thirdPlace = runner3;
            }

            Console.WriteLine($"1st place: {firstPlace} at {gold} minutes");
            Console.WriteLine($"2nd place: {secondPlace} at {silver} minutes");
            Console.WriteLine($"3rd place: {thirdPlace} at {bronze} minutes");
        }
    }
}