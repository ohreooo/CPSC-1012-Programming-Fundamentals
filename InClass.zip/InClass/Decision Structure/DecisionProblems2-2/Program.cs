﻿namespace DecisionProblems2_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char option;
            string originalUnit = "",
                convertedUnit = "",
                inputValue = "";
            double value = 0,
                convertedValue = 0;

            Console.WriteLine("Select from one of the following conversion options:");
            Console.WriteLine("\t1. Pounds to Kilograms");
            Console.WriteLine("\t2. Fluid Ounces to Litres.");
            Console.WriteLine("\t3. Inches to Centimeters");
            Console.WriteLine("\t4. Fahrenheit to Celsius");
            Console.Write("Option: ");
            option = char.Parse(Console.ReadLine().Substring(0, 1));

            switch (option)
            {
                case '1':
                    Console.Write("Enter pounds: ");
                    originalUnit = "lbs";
                    convertedUnit = "kg";
                    break;
                case '2':
                    Console.Write("Enter fluid ounces: ");
                    originalUnit = "fl oz";
                    convertedUnit = "L";
                    break;
                case '3':
                    Console.Write("Enter inches: ");
                    originalUnit = "in";
                    convertedUnit = "cm";
                    break;
                case '4':
                    Console.Write("Enter FahrenHeit: ");
                    originalUnit = "F";
                    convertedUnit = "C";
                    break;
                default:
                    Console.Write("Invalid Selection\n");
                    break;
            }

            try
            {
                inputValue = Console.ReadLine();
                value = double.Parse(inputValue);
                switch (option)
                {
                    case '1':
                        convertedValue = value / 2.20462;
                        break;
                    case '2':
                        convertedValue = value * 33.8140226;
                        break;
                    case '3':
                        convertedValue = value / 0.393701;
                        break;
                    case '4':
                        convertedValue = (value - 32) / 1.8;
                        break;
                    default:
                        Console.Write("Invalid Selection\n");
                        break;
                }
                Console.Write($"{value} {originalUnit} = {convertedValue:f2} {convertedUnit}");
            }

            catch (Exception)
            {
                Console.WriteLine("ERROR!! - Input string cannot be converted to a number");
            } 
        }
    }
}