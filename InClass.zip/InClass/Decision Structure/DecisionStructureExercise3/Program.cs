﻿namespace DecisionStructureExercise3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // setup for random numbers
            Random random = new Random();

            // declare variables
            int choice,
                computerChoice;
            string message = "",
                computerMessage = "",
                winnerMessage = "";
            // input
            Console.Write("Scissor (0), Rock (1), Paper (2): ");
            choice = int.Parse(Console.ReadLine());

            computerChoice = random.Next(0, 3);
            switch (choice)
            {
                case 0:
                    message = "You are scissor. ";
                    break;
                case 1:
                    message = "You are rock. ";
                    break;
                case 2:
                    message = "You are paper. ";
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
            switch (computerChoice)
            {
                case 0:
                    computerMessage = "The computer is scissor. ";
                    break;
                case 1:
                    computerMessage = "The computer is rock. ";
                    break;
                case 2:
                    computerMessage = "The computer is paper. ";
                    break;
                default:
                    break;
            }
            if (choice == computerChoice)
            {
                winnerMessage = "It is a draw.";
            }
            else
            {
                if ((choice == 0 && computerChoice == 1) || (choice == 1 && computerChoice == 2) || (choice == 2 && computerChoice == 0))
                    {
                    winnerMessage = "Computer wins.";
                }
                else
                {
                    winnerMessage = "You win.";
                }
            }
            Console.Write($"{computerMessage}{message}{winnerMessage}");
        }
    }
}