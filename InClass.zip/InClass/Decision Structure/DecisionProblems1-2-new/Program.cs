﻿/*
 * Purpose: Write a program that will determine the cost of admission for a theatre. The price of admission is
            based on the age of the customer. Your program should prompt the user for their age and then
            display the correct admission amount.
 * Input: Num1 <--age
 * Output: Admission amount
 * Author: Reonel Duque
 * Date: Sept. 14, 2022
 */
namespace DecisionProblem1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int num1;
            //double price; <- an easier way of doing it
            string message;

            //input number
            Console.Write("Enter age: ");
            num1 = int.Parse(Console.ReadLine());

            //determine admission amount
            if (num1 <= 6)
            {
                //price = 0;
                message = "FREE ($0.00)";
            }

            else if (num1 <= 17)
            {
                //price = 9.80;
                message = "$9.80";
            }
            else if (num1 <= 54)
            {
                //price - 11.35;
                message = "$11.35";
            }
            else
            {
                //price = 10;
                message = "$10.00";
            }

            //display results
            //Console.WriteLine($"The ticket price is {price:c}");
            Console.WriteLine($"The ticket price is {message}");
        }
    }
}