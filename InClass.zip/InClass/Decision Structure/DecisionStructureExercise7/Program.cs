﻿namespace DecisionStructureExercise7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // setup for random numbers
            Random random = new Random();

            // declare variables
            int number,
                suit;
            string numberMessage = "",
                suitMessage = "";

            // generate a random number between 1 and 10 inclusive
            // use the .Next() method
            // the first number in the parenthesis is the staring number
            // the second number in the parenthesis is the last number +1
            number = random.Next(1, 14);
            suit = random.Next(1, 5);

            switch (number)
            {
                case 1:
                    numberMessage = "Ace";
                    break;
                case 2:
                    numberMessage = "Two";
                    break;
                case 3:
                    numberMessage = "Three";
                    break;
                case 4:
                    numberMessage = "Four";
                    break;
                case 5:
                    numberMessage = "Five";
                    break;
                case 6:
                    numberMessage = "Six";
                    break;
                case 7:
                    numberMessage = "Seven";
                    break;
                case 8:
                    numberMessage = "Eight";
                    break;
                case 9:
                    numberMessage = "Nine";
                    break;
                case 10:
                    numberMessage = "Ten";
                    break;
                case 11:
                    numberMessage = "Jack";
                    break;
                case 12:
                    numberMessage = "Queen";
                    break;
                case 13:
                    numberMessage = "King";
                    break;
                default:
                    break;
            }
            switch (suit)
            {
                case 1:
                    suitMessage = " of Diamonds";
                    break;
                case 2:
                    suitMessage = " of Hearts";
                    break;
                case 3:
                    suitMessage = " of Clubs";
                    break;
                case 4:
                    suitMessage = " of Spades";
                    break;
                default:
                    break;
            }
            Console.Write($"The card you picked is {numberMessage}{suitMessage}");
        }
    }
}