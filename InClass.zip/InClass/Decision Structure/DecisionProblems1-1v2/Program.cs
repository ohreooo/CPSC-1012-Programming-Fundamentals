﻿namespace DecisionProblems1_1v2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            int num1;
            string message;

            // input a number
            Console.Write("Enter a number: ");
            num1 = int.Parse(Console.ReadLine());

            //determine if positive, negative, or zero
            if (num1 == 0)
            {
                message = "zero";
            }
            else if (num1 > 0)
            {
                message = "positive";
            }
            else
            {
                message = "negative";
            }

            //display results
            Console.WriteLine($"The number, {num1}, is {message}");
        }
    }
}