﻿namespace DecisionStructureExercise1
{
    internal class Program
    {
        static void Main(string[] args)
        {

                // setup for random numbers
                Random random = new Random();

                // declare variables
                int choice;
                int number;

                // get input
                Console.Write("0 or 1: ");
                choice = int.Parse(Console.ReadLine());

                // generate a random number between 1 and 10 inclusive
                // use the .Next() method
                // the first number in the parenthesis is the staring number
                // the second number in the parenthesis is the last number +1
                number = random.Next(0, 2);
                if (choice == number)
                {
                    Console.WriteLine("You guessed right");
                }
                else
                {
                    Console.WriteLine("You guessed wrong");
                }

        }
    }
}