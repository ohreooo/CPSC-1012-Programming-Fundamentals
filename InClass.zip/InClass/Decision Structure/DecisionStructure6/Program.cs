﻿namespace DecisionStructure6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int year;

            Console.Write("Enter a year: ");
            year = int.Parse(Console.ReadLine());

            year = year % 12;
            switch (year)
            {
                case 1:
                    Console.WriteLine("rooster");
                    break;
                case 2:
                    Console.WriteLine("dog");
                    break;
                case 3:
                    Console.WriteLine("pig");
                    break;
                case 4:
                    Console.WriteLine("rat");
                    break;
                case 5:
                    Console.WriteLine("ox");
                    break;
                case 6:
                    Console.WriteLine("tiger");
                    break;
                case 7:
                    Console.WriteLine("rabbit");
                    break;
                case 8:
                    Console.WriteLine("dragon");
                    break;
                case 9:
                    Console.WriteLine("snake");
                    break;
                case 10:
                    Console.WriteLine("horse");
                    break;
                case 11:
                    Console.WriteLine("goat");
                    break;
                case 12:
                    Console.WriteLine("monkey");
                    break;
                default:
                    Console.WriteLine("Not a valid year");
                    break;
            }
        }
    }
}