﻿/*
 * Purpose
 * Input
 * Output
 * Written by
 * Date
 */

namespace DecisionProblem2_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char package;
            int hours = 0;
            double total;

            // "\t" tab, "\n" new line
            // menu
            Console.WriteLine("Select the service package from the options below:");
            Console.WriteLine("\tA - $9.95 per month for up to 10 hours; additional hours are billed at $2.00 per hour");
            Console.WriteLine("\tB - $13.95 per month for up to 20 hours; additional hours are billed at $1.00 per hour");
            Console.WriteLine("\tC - $19.95 per month unlimited hours");

            //input variable
            Console.Write("Option: ");
            package = char.Parse(Console.ReadLine().ToUpper());

            switch (package)
            {
                case 'A':
                    Console.Write("Enter hours used: ");
                    hours = int.Parse(Console.ReadLine());
                    total = 9.95;
                    if (hours > 10)
                    {
                        total += ((hours - 10) * 2);
                    }
                    break;
                case 'B':
                    Console.Write("Enter hours used: ");
                    hours = int.Parse(Console.ReadLine());
                    total = 13.95;
                    if (hours > 20)
                    {
                        total += ((hours - 20));
                    }
                    break;
                case 'C':
                    total = 19.95;
                    break;
                default:
                    total = 0;
                    Console.WriteLine("Invalid selection");
                    break;
            }

            /*if (package == 'A'|| package == 'B')
            {
                Console.Write("Enter hours used: ");
                hours = int.Parse(Console.ReadLine());
            }
            if (package == 'A')
            {
                total = 9.95;
                if (hours > 10)
                {
                    total +=  ((hours - 10) * 2);
                }
            }
            else if (package == 'B')
            {
                total = 13.95;
                if (hours > 20)
                {
                    total += (hours - 20);
                }
            }
            else
            {
                total = 19.95;
            }*/

            Console.WriteLine($"The bill is {total:c}");

            Console.ReadLine();
        }
    }
}