﻿/*
 * Purpose: Output a Letter Grade based on Student's Mark
 * Input: num1
 * Output: letter grade
 * Author: Reonel Duque
 * Date: Sept 14, 2022
 */

namespace DecisionProblem1_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //define variables
            int num1;
            char message;

            //input number
            Console.Write("Enter mark: ");
            num1 = int.Parse(Console.ReadLine());

            //determine letter grade
            if (num1 <= 49)
            {
                message = 'F';
            }
            else if (num1 <= 69)
            {
              message =  'D';
            }
            else if (num1 <= 79)
            {
                message = 'C';
            }
            else if (num1 <= 89)
            {
                message = 'B';
            }
            else
            {
                message = 'A';
            }
                 

            //display results
            Console.WriteLine($"The grade for {num1} is {message}");

            Console.ReadLine();
        }
    }
}