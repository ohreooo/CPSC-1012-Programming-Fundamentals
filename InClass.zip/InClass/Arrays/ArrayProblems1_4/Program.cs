﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
       Purpose:   Create a program that will allow the user to enter marks for a quiz. The user will need the
                  ability to enter the following:
                      - The total for the quiz
                      - Up to, but no more than, 25 quiz marks and corresponding student names

                  Once the data has been entered, display a menu of options to the user to allow for the following:
                      - View all marks
                      - View the lowest mark
                      - View the lowest mark
                      - Find the mean average of the marks
                      - Quit the program

                  Each of the three view options should display the data as a table with appropriate headings.
                  The remaining options are left for you to implement as you see fit.
 
         Input:   quizTotal, name, mark, option      

        Output:   lowest, lowest, average     

   Modified By:   
 Last Modified:   
 
 */


namespace ArrayProblems1_4
{
    internal class Program
    {
        const int PhysicalSize = 25;
        const int MaxQuizMark = 100;
        static void Main(string[] args)
        {
            int[] marks = new int[PhysicalSize];
            string[] names = new string[PhysicalSize];
            int logicalSize,
                quizTotal,
                option;
            double average;

            //load the data
            quizTotal = GetSafeInt("Enter total for the quiz: ", MaxQuizMark);
            logicalSize = LoadArrays(marks, names, PhysicalSize, quizTotal);

            //main program loop
            do
            {
                DisplayMenu();
                option = GetSafeInt("Option: ", 5);
                switch (option)
                {
                    case 1:
                        ViewAllMarks(marks, names, logicalSize);
                        break;
                    case 2:
                        ViewHighestMark(marks, names, logicalSize);
                        break;
                    case 3:
                        ViewLowestMark(marks, names, logicalSize);
                        break;
                    case 4:
                        average = FindMeanAverage(marks, logicalSize);
                        Console.WriteLine($"Quiz average = {average:f2}");
                        break;
                    default:
                        Console.WriteLine("Goodbye ...");
                        break;
                }//end switch
            } while (option != 5);

            Console.ReadLine();
        }//eom

        static void ViewAllMarks(int[] marks, string[] names, int size)
        {
            Console.WriteLine("Mark");
            for (int index = 0; index < size; index++)
            {
                Console.WriteLine($"{names[index]}\t{marks[index]}");
            }
        }//end of ViewAllMarks

        static void ViewHighestMark(int[] marks, string[] names, int size)
        {
            int highest = marks[0],
                location = 0;
            for (int index = 1; index < size; index++)
            {
                if (marks[index] > highest)
                {
                    highest = marks[index];
                    location = index;
                }
            }//end for

            Console.WriteLine("Name\\ttMark");
            Console.WriteLine($"{names[location]}\t\t{marks[location]}");
        }//end of ViewHighestMark

        static void ViewLowestMark(int[] marks, string[] names, int size)
        {
            int lowest = marks[0],
                location = 0;
            for (int index = 1; index < size; index++)
            {
                if (marks[index] < lowest)
                {
                    lowest = marks[index];
                    location = index;
                }
            }//end for

            Console.WriteLine("Name\t\tMark");
            Console.WriteLine($"{names[location]}\t\t{marks[location]}");
        }//end of ViewLowestMark

        static int GetSafeInt(string prompt, int total)
        {
            bool isValid = false;
            int number = 0;
            do
            {
                try
                {
                    Console.Write(prompt);
                    number = int.Parse(Console.ReadLine());
                    if (number >= 0 && number <= total)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine($"Invalid mark entered (max is {total}) ... try again");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Not an integer value ... try again");
                }
            } while (!isValid);
            return number;
        }//end of GetSafeInt

        static string GetSafeString(string prompt)
        {
            bool isValid = false;
            string text;
            do
            {
                Console.Write(prompt);
                text = Console.ReadLine();
                if (text.Length >= 2)
                {
                    isValid = true;
                }
                else
                {
                    Console.WriteLine("Invalid entry ... try again");
                }
            } while (!isValid);
            return text;
        }//end of GetSafeString

        static char GetSafeChar(string prompt)
        {
            bool isValid = false;
            char character = ' ';
            do
            {
                try
                {
                    Console.Write(prompt);
                    character = char.Parse(Console.ReadLine().ToUpper());
                    if (character == 'Y' || character == 'N')
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("Not a valid character ... try again");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Not a valid character ... try again");
                }
            } while (!isValid);
            return character;
        }//end of GetSafeChar

        static int LoadArrays(int[] marks, string[] names, int size, int quizTotal)
        {
            int logicalSize = 0,
                mark;
            string name;
            char another = 'Y';
            while (another == 'Y' && logicalSize < size)
            {
                name = GetSafeString("Enter student's name: ");
                mark = GetSafeInt("Enter student's mark: ", quizTotal);
                names[logicalSize] = name;
                marks[logicalSize] = mark;
                logicalSize++;
                another = GetSafeChar("Add another (Y/N): ");
            }//end while
            return logicalSize;
        }//end of LoadArrays

        static double FindMeanAverage(int[] marks, int size)
        {
            double average = 0;
            for (int index = 0; index < size; index++)
            {
                average += marks[index];
            }
            return average / size;
        }//end of FindMeanAverage

        static void DisplayMenu()
        {
            Console.WriteLine("\nSelect from the following options");
            Console.WriteLine("\t1. View all marks");
            Console.WriteLine("\t2. View the highest mark");
            Console.WriteLine("\t3. View the lowest mark");
            Console.WriteLine("\t4. Find the mean average of the marks");
            Console.WriteLine("\t5. Quit the program");
        }//end of DisplayMenu
    }//eoc
}//eon