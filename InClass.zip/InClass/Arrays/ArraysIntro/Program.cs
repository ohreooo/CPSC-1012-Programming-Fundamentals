﻿namespace ArraysIntro
{
    internal class Program
    {
        static void Main()
        {
            const int PhysicalSize = 5;
            int[] age = new int[6];
            double[] mark = new double[25];
            string[] daysOfWeek = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
            int[] userData = new int[PhysicalSize];

            /*for (int index = 0; index < 6; index++)
            {
                Console.WriteLine($"{age[index]}");
            }

            for (int index = 0; index < 7; index++)
            {
                Console.WriteLine($"{daysOfWeek[index]}");
            }
            */

            //user entered data
            /*
            for(int index = 0; index < PhysicalSize; index++)
            {
                Console.Write("Enter data here: ");
                userData[index] = int.Parse(Console.ReadLine());
            }

            for (int index = 0; index < PhysicalSize; index++)
            {
                Console.WriteLine($"{userData[index]}");
            }
            */
            LoadArray(userData, PhysicalSize);
            DisplayArray(userData, PhysicalSize);
            Console.ReadLine();
        }

        //load array method
        static void LoadArray(int[] userData, int size)
        {
            for (int index = 0; index < size; index++)
            {
                Console.Write("Enter data here: ");
                userData[index] = int.Parse(Console.ReadLine());
            }
        }

        static void DisplayArray(int[] arrayName, int size)
        {
            for (int index = 0; index < size; index++)
            {
                Console.WriteLine(arrayName[index]);
            }
        }
    }
}