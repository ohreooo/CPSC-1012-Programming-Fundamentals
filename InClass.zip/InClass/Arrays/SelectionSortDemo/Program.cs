﻿

using System.Reflection.Metadata.Ecma335;

namespace SelectionSortDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers;
            int count,
                searchNumber,
                searchLocation;
            double average;
            const int PhysicalSize = 25;
            numbers = new int[PhysicalSize];

            LoadArrayRandom(numbers, PhysicalSize);
            DisplayArray(numbers, PhysicalSize);
            SelectionSort(numbers, PhysicalSize);
            DisplayArray(numbers, PhysicalSize);
            average = CalculateAverage(numbers, PhysicalSize);
            count = CountAboveAverage(numbers, PhysicalSize, average);
            Console.WriteLine($"The average is {average:f2} and the number of people above average is {count}");
            Console.Write("Enter a number to be searched: ");
            searchNumber = int.Parse(Console.ReadLine());
            searchLocation = BinarySearch(numbers, PhysicalSize, searchNumber);
            Console.WriteLine($"Index is in {searchLocation}");

        }

        static void LoadArrayRandom(int[] numbers, int size)
        {
            Random random = new Random();
            for(int index = 0; index < size; index++)
            {
                numbers[index] = random.Next(1, 101);
            }    
        }

        static void DisplayArray(int[] numbers, int size)
        {
            for(int index = 0; index < size; index++)
            {
                Console.WriteLine($"{index} \t{numbers[index]}");
            }
        }
        static void SelectionSort(int[] numbers, int size)
        {
            int minIndex, minValue;
            int temp;
            for (int startScan = 0; startScan < size - 1; startScan++)
            {
                //assume, for now, the first element has the smallest value
                minValue = numbers[startScan];
                //now look at the rest of the array
                for (int index = startScan; index < size; index++)
                {
                    if (numbers[index] < minValue)
                    {
                        minValue = numbers[index];
                        minIndex = index;
                        //now swap
                        temp = numbers[minIndex];
                        numbers[minIndex] = numbers[startScan];
                        numbers[startScan] = temp;
                    }//end if
                }//end inner for
            }//end outer for
        }//end of SelectionSort

        static double CalculateAverage(int[] numbers, int count)
        {
            int counter = 0;
            double average = 0;
            for (; counter < count; counter++)
            {
                average += numbers[counter];
            }
            return (average / count);
        }

        static int CountAboveAverage(int[] numbers, int size, double average)
        {
            int count = 0;
            for(int index = 0; index < size; index++)
            {
                if (numbers[index] > average)
                {
                    count++;
                }
            }
            return count;
        }

        static int BinarySearch(int[] numbers, int size, int searchNumber)
        {
            //ensure the array is sorted
            SelectionSort(numbers, size);

            //declare local variables
            int first = 0,
                last = size - 1,
                middle = (first + last) / 2,
                location = -1;

            //loop through the array
            while (first <= last && location == -1)
            {
                if (searchNumber > numbers[middle])
                {
                    first = middle + 1;

                }
                else if (searchNumber < numbers[middle])
                {
                    last = middle - 1;
                }
                else
                {
                    location = middle;
                }
                middle = (first + last) / 2;
            }
            return location;
        }
    }
}
