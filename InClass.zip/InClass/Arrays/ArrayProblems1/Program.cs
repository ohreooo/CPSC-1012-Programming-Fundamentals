﻿using System.Transactions;

namespace ArrayProblems1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int PhysicalSize = 3;
            int[] numbers = new int[PhysicalSize];
            int count = 0,
                largest,
                smallest;
            double average = 0;

            count = LoadArray(numbers, PhysicalSize);
            average = CalculateAverage(numbers, count);
            largest = LargestNumber(numbers, count);
            smallest = SmallestNumber(numbers, count);
            Console.WriteLine($"Average is {average}");
            Console.WriteLine($"Largest is {largest}");
            Console.WriteLine($"Smallest is {smallest}");
        }

        static int GetSafeInt(string prompt)
        {
            bool isValid = false;
            int number;
            do
            {
                Console.Write(prompt);
                isValid = int.TryParse(Console.ReadLine(), out number);
            } while (!isValid);
            return number;
        }//end of GetSafeInt
        static int LoadArray(int[] numbers, int size)
        {
            int count = 0,
                number;
            char addAnother;
            bool test = false;
            do
            {
                number = GetSafeInt("Enter a number to add to the array: ");
                numbers[count] = number;
                count++;
                if (count == size)
                {
                    addAnother = 'N';
                }
                else
                {
                    Console.Write("Add another (y/n): ");
                    addAnother = char.Parse(Console.ReadLine().ToUpper().Substring(0, 1));
                }
            } while (addAnother != 'N');
            return count;
        }

        static double CalculateAverage(int[] numbers, int count)
        {
            int counter = 0;
            double average = 0;
            for (; counter < count; counter++)
            {
                average += numbers[counter];
            }
            return (average / count);
        }

        static int LargestNumber(int[] numbers, int count)
        {
            int largest = numbers[0];
            for (int index = 1; index < count; index++)
            {
                if (numbers[index] > largest)
                {
                    largest = numbers[index];
                }
            }
            return largest;
        }

        static int SmallestNumber(int[] numbers, int count)
        {
            int smallest = numbers[0];
            for (int index = 1; index < count; index++)
            {
                if (numbers[index] < smallest)
                {
                    smallest = numbers[index];
                }
            }
            return smallest;
        }

        static int Mode(int[] numbers, int count)
        {
            //find the highest number in the array, which was previously sorted
            int max = LargestNumber(numbers, count);
            int top = max + 1;
            int[] modeCount = new int[top];
            //initialize the modeCount array to all 0's
            for (int index = 0; index < top; index++)
            {
                modeCount[index] = 0;
            }
            //store the modeCount of each element of the input array
            for (int index = 0; index < count; index++)
            {
                modeCount[numbers[index]]++;
            }
            //mode is the index with the maximum modeCount
            int mode = 0;
            int countMode = modeCount[0];
            for (int index = 1; index < top; index++)
            {
                if (modeCount[index] > countMode)
                {
                    countMode = modeCount[index];
                    mode = index;
                }
            }
            return mode;
        }//end of Mode
    }
}