﻿namespace SequentialSearchDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Bob", "Dave", "Sally", "Betty", "Ziggy", "Fred", "Wilma", "Barney", "Scooby" };
            string searchName; // the value I want to search for
            int index; // the location of the search item

            //prompt for searchName
            Console.Write("Enter first name to search: ");
            searchName = Console.ReadLine();
            index = SearchArray(names, 9, searchName);
            if (index == -1)
            {
                Console.WriteLine($"The name {searchName} is not in the array");
            }
            else
            {
                Console.WriteLine($"The name {searchName} is at index {index}");
            }
            SelectionSort(names, 9);
            DisplayArray(names, 9);
        }

        static int SearchArray(string[] names, int size, string searchName)
        {
            int location = -1; //value of -1 indicates the searchName was not found
            for(int index = 0; index < size; index++)
            {
                if (searchName.ToUpper() == names[index].ToUpper())
                {
                    location = index;
                    index = size;
                }
            }
            return location;
        }

        static void SelectionSort(string[] names, int size)
        {
            int minIndex;
            string minValue,
                temp;
            for (int startScan = 0; startScan < size - 1; startScan++)
            {
                //assume, for now, the first element has the smallest value
                minValue = names[startScan];
                //now look at the rest of the array
                for (int index = startScan; index < size; index++)
                {
                    if (string.Compare(names[index], minValue) < 0)
                    {
                        minValue = names[index];
                        minIndex = index;
                        //now swap
                        temp = names[minIndex];
                        names[minIndex] = names[startScan];
                        names[startScan] = temp;
                    }//end if
                }//end inner for
            }//end outer for
        }//end of SelectionSort

        static void DisplayArray(string[] names, int size)
        {
            for (int index = 0; index < size; index++)
            {
                Console.WriteLine($"{index} \t{names[index]}");
            }
        }
    }
}