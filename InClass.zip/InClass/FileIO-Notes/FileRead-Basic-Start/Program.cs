﻿/*
       Purpose:   Demonstrate a simple File Read    
         Input:   Students.txt      
        Output:   formated output of the file     
    Written By:   
 Last Modified:   
 */

//add the following namespace for reading/writing from/to a file
using System.IO;

namespace FileRead_Basic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            const string PathAndFile = @"E:\CPSC1012\VisualStudio2022Code\InClass\FileIO-Notes\Students.txt"; //= to the directory address of the file. You can try it with the folders having spaces in the name and switching the " " to "_" but it didn't work for me. Instead of '@"E:\SchoolStuff...' where "\" is written once, you can do "E:\\SchoolStuff...." without the "@" at the beginning
            string input;
            // 1. Test if the file exists
            if (File.Exists(PathAndFile))
            {
                // 2. Setup the StreamReader
                //before "StreamReader reader = null;", use "Console.WriteLine("exists");" to test if the program can find the file
                StreamReader reader = null;

                // 3. Use a try-catch-finally to read & display file contents
                try
                {
                    // 4. Open the file for reading
                    reader = File.OpenText(PathAndFile);

                    // 5. Use a while loop to loop through the file
                    while ((input = reader.ReadLine()) != null) //reads one line of text at a time until there is no text left -> "!= null"
                    {
                        // 6. Read and display the data from a line of the file
                        Console.WriteLine(input);
                    }
                }
                catch (Exception ex)
                {
                    // 7. Display any exceptions
                    Console.WriteLine(ex.Message); //if anything goes wrong in the try, this will display the error message
                }
                finally
                {
                    // 8. Close the StreamReader
                    reader.Close();
                }
                // end of file read and display
            }
            else
            {
                // 9. Information message if the file does not exist
                Console.WriteLine($"The file, {PathAndFile}, does not exist");
            }

            Console.ReadLine();
        }
    }
}