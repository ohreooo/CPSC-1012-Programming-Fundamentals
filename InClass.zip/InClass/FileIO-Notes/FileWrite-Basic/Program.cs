﻿/*
       Purpose:   Demonstrate how to write/create a file    
         Input:   name      
        Output:   StudentsList.txt    
    Written By:   
 Last Modified:   
 */

//add the following namespace for reading/writing from/to a file
using System.IO;
namespace FileWrite_Basic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            const string PathAndFile = @"E:\CPSC1012\VisualStudio2022Code\InClass\FileIO-Notes\Students.txt";
            string name;

            // 1. Create a StreamWriter
            StreamWriter writer = null;

            // 2. Use a try-catch-finally
            try
            {
                // 3. Initialize the StreamWriter
                writer = File.CreateText(PathAndFile);

                // 4. Prompt for a name, or zzz to exit
                Console.Write("Enter a name or zzz to quit: ");
                name = Console.ReadLine();

                // 5. Loop while name is not "zzz"
                while (!name.ToLower().Equals("zzz"))
                {
                    // 6. Write the name to the file
                    writer.WriteLine(name);
                    // 7. Re-prompt for the name of zzz to exit
                    //    Do not write the "zzz" value to the file!
                    Console.Write("Enter a name or zzz to quit: ");
                    name = Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                // 8. Display the exception message if it occurs
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // 9. Close the StreamWriter
                writer.Close();
            }
            Console.ReadLine();
        }
    }
}