﻿namespace ReadShoppingOrder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string PathAndFile = @"E:\CPSC1012\VisualStudio2022Code\InClass\FileIO-Notes\ShoppingOrder.csv";
            string productName,
                input;
            double price,
                total;
            int quantity;

            StreamReader reader = null;

            try
            {
                reader = File.OpenText(PathAndFile);
                Console.WriteLine($"{"Product Name", -16}{"Price", -5}{"Qty", -3}{"Line Total", -9}");
                while ((input = reader.ReadLine()) != null)
                {
                    string[] part = input.Split(',');
                    productName = part[0];
                    price
                }

            }
            catch (Exception)
            {


            }
            finally
            {

            }
        }
    }
}