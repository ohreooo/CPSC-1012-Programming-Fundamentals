﻿namespace ReadCourseList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string PathAndFile = @"E:\CPSC1012\VisualStudio2022Code\InClass\FileIO-Notes\Courses.csv";
            string courseId,
                courseName,
                input;
            double credits;
            int count = 0;

            StreamReader reader = null;

            try
            {
                Console.WriteLine($"{"Course ID", -12}{"Name", -60}{"Credits", -4}");
                reader = File.OpenText(PathAndFile);
                while ((input = reader.ReadLine()) != null)
                {
                    string[] parts = input.Split(',');
                    courseId = parts[0];
                    courseName = parts[1];
                    credits = double.Parse(parts[2]);
                    Console.WriteLine($"{courseId,-12}{courseName,-60} {credits,-4}");
                    count++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                reader.Close();
            }
            Console.WriteLine($"{count} records from file.");
        }
    }
}