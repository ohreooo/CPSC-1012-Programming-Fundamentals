﻿/*
    Purpose: Create a simple calculator

    Input: Number 1, Number 2

    Output: Sum, Difference(1 - 2), Product, Quotient(1 / 2)

    Author: Reonel Duque

    Date: September 7, 2022
*/

namespace BasicProgrammingProblem2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables and constants
            const double SquareFtConvert = 43560;
            double convertedNumber,
                number1;

            // input 1 numbers
            Console.Write("Enter the number of square feet: "); //Write outputs a text in a line without starting a new line, WriteLine outputs a text in a line and starts a new line
            number1 = double.Parse(Console.ReadLine());

            //converting the number
            convertedNumber = number1 / SquareFtConvert;

            //display results
            Console.WriteLine($"There are {convertedNumber:f2} in {number1} square feet of land");

        }
    }
}