﻿/*
    Purpose: Determine West Coast Sales

    Input: n/a

    Output: sales

    Author: Reonel Duque

    Date: September 7, 2022
*/

namespace BasicProgrammingProblem1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare constants
            const double Percentage = 0.43; //has to have number if const, and const has to be named with Capitalized letters

            // declare variables
            double westSales,
                  totalSales = 5300000.00;

            //Calculate 43% of total sales
            westSales = totalSales * Percentage;
      
            //display results
            Console.WriteLine($"The company earned {westSales:c} on {totalSales:c}"); // c is currency
           
        }
    }
}