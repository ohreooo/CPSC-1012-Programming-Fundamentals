﻿namespace PracticeObjectProblem2
{
    internal class CD
    {
        //private member fields
        private string _title;
        private Artist _artist;
        private int _tracks;
        private double _price;

        //public Accessors & Mutators
        public string Title
        {
            get { return _title; }
            set
            {
                //validation check
                if (value.Length > 0)
                {
                    _title = value;
                }
                else
                {
                    throw new Exception("Invalid title (min 1 character)");
                }
            }
        }//end of Title

        public Artist Artist
        {
            get { return _artist; }
            set { _artist = value; } //already checked if Artist is valid in the Artist class
        }//end of Artist

        public int Tracks
        {
            get { return _tracks; }
            set
            {
                if (value > 0)
                {
                    _tracks = value;
                }
                else
                {
                    throw new Exception("Invalid track (min value of 1)");
                }
            }
        }//end of Tracks

        public double Price
        {
            get { return _price; }
            set
            {
                if (value >= 0)
                {
                    _price = value;
                }
                else
                {
                    throw new Exception("Invalid price (min value of 0.00)");
                }
            }
        }//end of Price

        //Constructor
        public CD(string title, Artist artist, int tracks, double price)
        {
            Title = title;
            Artist = artist;
            Tracks = tracks;
            Price = price;
        }//end of CD

        //Class Method
        public string CDInfo()
        {
            return $"{Title,-20}{Artist,-20}{Price,8:c}{Tracks,12}";
        }//end of CDInfo
    }
}
