﻿namespace PracticeObjectProblem2
{
    internal class Program
    {
        const int PhysicalSize = 25;
        static void Main(string[] args)
        {

            CD[] cds = new CD[PhysicalSize];
            int logicalSize;

            try
            {
                logicalSize = LoadArray(cds, PhysicalSize);
                DisplayArray(cds, logicalSize);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }//end of Main

        static CD CreateCD()
        {
            string title,
                firstname,
                lastname;

            int tracks;
            double price;

            title = GetSafeString($"{"Enter CD title: ", 28}"); //to align all texts
            firstname = GetSafeString($"{"Enter Artist's first name: ",28}");
            lastname = GetSafeString($"{"Enter Artist's last name: ",28}");
            tracks = GetSafeInt($"{"Enter # of tracks: ",28}", 1);
            price = GetSafeDouble($"{"Enter CD price: ",28}", 0);

            CD cd = new CD(title, new Artist(firstname, lastname), tracks, price);

            Console.Write("Enter CD title: ");
            return cd;
        }

        static int GetSafeInt(string prompt, int minValue)
        {
            bool isValid = false;
            int number = 0;

            do
            {
                try
                {
                    Console.Write(prompt);
                    number = int.Parse(Console.ReadLine());

                    if (number >= minValue)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("invalid range!");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("invalid integer!");
                }
            } while (!isValid);

            return number;
        }//end of GetSafeInt

        static string GetSafeString(string prompt)
        {
            bool isValid = false;
            string text;
            do
            {
                Console.Write(prompt);
                text = Console.ReadLine();
                if (text.Length > 0)
                {
                    isValid = true;
                }

            } while (!isValid);
            return text;
        }//end of GetSafeString

        static double GetSafeDouble(string prompt, int minValue)
        {
            bool isValid = false;
            double number = 0;

            do
            {
                try
                {
                    Console.Write(prompt);
                    number = double.Parse(Console.ReadLine());

                    if (number >= minValue)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("invalid range!");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("invalid integer!");
                }
            } while (!isValid);

            return number;
        }//end of GetSafeInt

        static int LoadArray(CD[] cds, int size)
        {
            int logicalSize = 0;
            char another;

            do
            {
                //create a CD object & store the CD object in the array
                cds[logicalSize] = CreateCD();

                //increment the logicalSize
                logicalSize++;
                

                //check to make sure the array is not full
                if(logicalSize < size)
                {
                    //prompt to add another CD
                    Console.Write(" Add another CD (y/n): ");
                    another = char.Parse(Console.ReadLine().ToUpper().Substring(0, 1));
                }

                else
                {
                    another = 'N';
                }
                //prompt to add another CD
            } while (another == 'Y');

            return logicalSize;
        }//end of LoadArray

        static void DisplayArray(CD[] cds, int size)
        {
            //column headings
            Console.WriteLine($"{"Title", -20}{"Arist", -20}{"Price", 8}{"Tracks", 12}");
            for (int index = 0; index < size; index++)
            {
                Console.WriteLine(cds[index].CDInfo());
            }
        }//end of DisplayaArray
    }
}