﻿
namespace PracticeObjectProblem2
{
    internal class Artist
    {
        //private member fields
        private string _firstname;
        private string _lastname;

        //public Accessors & Mutators
        public string Firstname
        {
            get { return _firstname; }
            set
            {
                //validation check
                if (value.Length > 0)
                {
                    _firstname = value;
                }
                else
                {
                    throw new Exception("Invalid firstname (min 1 character)");
                }
            }
        }//end of Firstname

        public string Lastname
        {
            get { return _lastname; }
            set
            {
                //validation check
                if (value.Length > 0)
                {
                    _lastname = value;
                }
                else
                {
                    throw new Exception("Invalid lastname (min 1 character)");
                }
            }
        }//end of Firstname

        //Constructor
        public Artist(string firstName, string lastName)//does not have to be camelcase for constructor
        {
            Firstname = firstName;
            Lastname = lastName;
        }

        //Class Method
        public override string ToString()
        {
            return $"{Lastname}, {Firstname}";
        }//end of ToString
    }
}
