﻿
using System.Xml.Linq;

namespace OOP_Intro
{
    internal class Quiz
    {
        //private member fields
        private string _studentName;
        private int _total;
        private int _mark;
        private int _weight;

        //private read and write properties
        public string StudentName
        {
            get
            { 
                return _studentName;
            }
            set
            {


                if (value.Length > 0)
                {
                    _studentName = value;
                }
                else
                {
                    throw new Exception("Invalid name.");
                }
            }
        }//end of StudentName

        public int Total
        {
            get 
            {
                return _total;
            }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    _total = value;
                }
                else
                {
                    throw new Exception("Invalid grade.");
                }
            }
        }//end of Total

        public int Mark
        {
            get
            { 
                return _mark;
            }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    _mark = value;
                }
                else
                {
                    throw new Exception("Invalid grade.");
                }
            }
        }//end of Mark

        public int Weight
        {
            get
            {
                return _weight;
            }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    _weight = value;
                }
                else
                {
                    throw new Exception("Invalid grade.");
                }
            }
        }//end of Weight

        public Quiz(int mark, int total, int weight, string studentName)
        {
            StudentName = studentName;
            Total = total;
            Mark = mark;
            Weight = weight;
        }//end of Quiz

        public double GetPercentage()
        {
            return ((Mark * 100.00) / Total);
        }
    }
}
