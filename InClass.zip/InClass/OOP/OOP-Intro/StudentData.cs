﻿namespace OOP_Intro
{
    internal class StudentData
    {
        //private member fields - use "_" before name
        private string _name;
        private int _grade;

        //public Accessors & Mutators
        public string Name
        {
            get { return _name; }
            // the below statement is sloppy
            // set { _name = value;
            //do below instead
            set
            {


                if (value.Length > 0)
                {
                    _name = value;
                }
                else
                {
                    throw new Exception("Invalid name.");
                }
            }
        }//end of Name

        public int Grade
        {
            get { return _grade; }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    _grade = value;
                }
                else
                {
                    throw new Exception("Invalid grade.");
                }
            }
        }//end of Grade
        //Accessors are for read, Mutators are for Write
        //get -> an accessor
        //set -> a mutator
        //value is special keyword having a value you want to pass into any properties, value is any datatype

        //Constructor(s)
        // constructor has same ??

        //StudentData() is an empty constructor --> will put default
        public StudentData()
        {
            Name = "John Doe";
            Grade = 0;
        }

        public StudentData(string name, int grade)
        {
            Name = name;
            Grade = grade;
        }

        //StudentData(string name, int grade) is a greedy constructor -->it wants data/input

        //Class Method(s)
        public override string ToString() //override is needed cause there's already a ToString Method
        {
            return $"Name: {Name}\tGrade: {Grade}";
        }//end of ToString
    }
}
