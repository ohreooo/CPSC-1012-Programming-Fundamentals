﻿namespace OOP_Intro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {

                //Create a default instance of StudentData
                StudentData student1 = new StudentData();
                // student1 is the instance name or object name of the class StudentData

                //Create a non-default instance of StudentData
                StudentData student2 = new StudentData("Allan Anderson", 50);
                StudentData student3 = new StudentData("Hello", 50);
                //Display the properties of the objects
                Console.WriteLine($"Name: {student1.Name}, Grade: {student1.Grade}");

                //Display the instances
                Console.WriteLine(student1);
                Console.WriteLine(student2);

                student3.Grade = -1;
                Console.WriteLine(student3);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}