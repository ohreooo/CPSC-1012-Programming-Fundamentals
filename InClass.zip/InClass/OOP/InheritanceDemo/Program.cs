﻿using InheritanceDemo.Classes;

/* 
Purpose:		This demonstrates Object inheritance	 
Input:			data for each of the classes	
Output:			data from each of the classes 
Written By: 	Foster Cherkewick
Last Modified:  Nov 23, 2022
*/

namespace InheritanceDemo
{
    class Program
    {
        static void Main()
        {
            Setup();
            List<Person> people = new List<Person>(); //Class Person


            LoadPersons(people);
            Console.WriteLine("All person objects");
            DisplayPersons(people);

            Console.WriteLine("\n Only student objects");
            DisplayStudents(people);

            Console.WriteLine("\n Only instructor objects");
            Displayinstructors(people);


            Console.ReadLine();
        }//eom

        static void LoadPersons(List<Person> people)
        {
            //1. Add default person
            people.Add(new Person());
            //2. Add some instructors
            people.Add(new Instructor(2, "Dirk", "Diggy", new ContactInfo("mremail@durh.com", "780-888-2222"), "W309"));
            people.Add(new Instructor(3, "Mr", "man", new ContactInfo("EmailMan@ooooo.com", "587-655-9999"), "V200"));
            //3. Add some students
            people.Add(new Student(1288, "Foster", "Cherkewick", new ContactInfo("Fcherkewick1@nait.ca", "780-800-3636"), "CSD", 1));
        }//end of LoadPersons

        static void DisplayPersons(List<Person> people)
        {
            //Display All person objects in the list
            foreach (Person person in people)
            {
                Console.WriteLine(person);
            }

        }//end of DisplayPersons

        static void DisplayStudents(List<Person> people)
        {
            //Only display students
            foreach (Person person in people)
            {
                if (person.GetType() == typeof(Student))
                {
                    Console.WriteLine(person);
                }
            }
        }//end of DisplayStudents

        static void Displayinstructors(List<Person> people)
        {
            //only display instructors
            foreach (Person person in people)
            {
                if (person.GetType() == typeof(Instructor))
                {
                    Console.WriteLine(person);
                }
            }
        }//end of Displayinstructors

        static void Setup()
        {
            Console.Title = "Inheritance Demo";
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
        }//end of Setup

        #region Methods You Can Use - May need to modify
        static int GetSafeInt(string prompt)
        {
            int number = 1;
            bool isValid = false;
            do
            {
                try
                {
                    Console.Write("{0,20}", prompt);
                    number = int.Parse(Console.ReadLine());
                    if (number >= 0)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("ERROR: Invalid number ... try again");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("ERROR: Invalid number ... try again");
                }
            } while (!isValid);
            return number;
        }//end of GetSafeInt

        static string GetSafeString(string prompt)
        {
            string name;
            bool isValid = false;
            do
            {
                Console.Write("{0,20}", prompt);
                name = Console.ReadLine();
                if (name.Length >= 3)
                {
                    isValid = true;
                }
                else
                {
                    Console.WriteLine("ERROR: Name is not valid");
                }
            } while (!isValid);
            return name;
        }//end of GetSafeString

        static char GetSafeChar(string prompt)
        {
            char option;
            bool isValid = false;
            do
            {
                try
                {
                    Console.Write(prompt);
                    option = char.ToUpper(char.Parse(Console.ReadLine()));
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid option ... try again");
                    option = ' ';
                }
            } while (!isValid);
            return option;
        }//end of GetSafeChar
        #endregion
    }//eoc
}//eon
