﻿/*
    +-----------------------------------------------+
    | ContactInfo                                   |
    +-----------------------------------------------+
    | - email : String                              |
    | - phone : String                              |
    | + Email : String                              |
    | + Phone : String                              |
    +-----------------------------------------------+
    | + ContactInfo(Email : String, Phone : String) |
    | + ToString() : String                         |
    +-----------------------------------------------+
 */

namespace InheritanceDemo.Classes
{
    public class ContactInfo
    {
        private string _email;
        private string _phone;

        public string Email
        {
            get { return _email; }
            set
            {
                if (value.Length >= 5)
                {
                    _email = value;
                }
                else
                {
                    throw new Exception("Invalid contact email");
                }
            }
        }//End of email
        public string Phone
        {
            get { return _phone; }
            set
            {
                if (value.Length >= 10)
                {
                    _phone = value;
                }
                else
                {
                    throw new Exception("Invalid contact phone");
                }
            }
        }//End of phone

        public ContactInfo(string email, string phone)
        {
            Email = email;
            Phone = phone;
          
        }//End of constructor contact info

        public override string ToString()
        {
            return $"Email: {Email}\nPhone: {Phone}";
        }
    }//eoc
}//eon
