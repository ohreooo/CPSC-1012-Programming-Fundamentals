﻿/*

    +---------------------------------------------------------------------------------------------+
    | Student                                                                                     |
    +---------------------------------------------------------------------------------------------+
    | - program : String                                                                          |
    | - semester : Integer                                                                        |
    | + Program : String                                                                          |
    | + Semester : Integer                                                                        |
    +---------------------------------------------------------------------------------------------+
    | + Student(IDNumber : Integer, LastName : String, FirstName : String, Contact : ContactInfo, |
    |           Program : String, Semester : Integer)                                             |
    | + ToString() : String                                                                       |
    +---------------------------------------------------------------------------------------------+

 */
namespace InheritanceDemo.Classes
{
    public class Student : Person
    {

        private string _program;
        private int _semester;

        public string Program
        {
            get { return _program; }
            set
            {
                if(value.Length >= 2)
                {
                    _program = value;
                }
                else
                {
                    throw new Exception("Invalid program");
                }
            }
        }//End of program
        public int Semester
        {
            get { return _semester; }
            set
            {
                if(value >= 1)
                {
                    _semester = value;
                }
                else
                {
                    throw new Exception("Invalid Semester");
                }
            }
        }//End of semester

        public Student(int ID, string lastName, string firstName, ContactInfo contact, string program, int semester)
        {
            IdNumber = ID;
            LastName = lastName;
            FirstName = firstName;
            Contact = contact;
            Program = program;
            Semester = semester;
        }//End of student
        public override string ToString()
        {
            return $"ID: {IdNumber}, Name: {LastName}, {FirstName}, Contact: {Contact}, Program: {Program}, Semester: {Semester}";
        }

    }//eoc
}//eon
