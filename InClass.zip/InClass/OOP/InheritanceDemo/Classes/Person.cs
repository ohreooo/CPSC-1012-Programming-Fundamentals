﻿/*
 
    +--------------------------------------------------------------------------------------------+
    | Person                                                                                     |
    +--------------------------------------------------------------------------------------------+
    | - idNumber : Integer                                                                       |
    | - lastName : String                                                                        |
    | - firstName : String                                                                       |
    | - contact : ContactInfo                                                                    |
    | + IDNumber : Integer                                                                       |
    | + LastName : String                                                                        |
    | + FirstName : String                                                                       |
    | + Contact : ContactInfo                                                                    |
    +--------------------------------------------------------------------------------------------+
    | + Person()                                                                                 |
    | + Person(IDNumber : Integer, LastName : String, FirstName : String, Contact : ContactInfo) |
    | + ToString() : String                                                                      |
    +--------------------------------------------------------------------------------------------+

 */

namespace InheritanceDemo.Classes
{
    public class Person
    {
        private int _idNumber;
        private string _firstName;
        private string _lastName;
        private ContactInfo _contact;

        public int IdNumber
        {
            get { return _idNumber; }
            set
            {
                if(value > 0)
                {
                    _idNumber = value;
                }
                else
                {
                    throw new Exception("Invalid ID Number");
                }
            }
        }//End of IDnumber

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                if(value.Length >= 2)
                {
                    _firstName = value;
                }
                else
                {
                    throw new Exception("Invalid Length first name");
                }
            }
        }//End of firstname
        public string LastName
        {
            get { return _lastName; }
            set
            {
                if (value.Length >= 2)
                {
                    _lastName = value;
                }
                else
                {
                    throw new Exception("Invalid Length last name");
                }
            }
        }//End of last name

        public ContactInfo Contact
        {
            get { return _contact; }
            set { _contact = value; }
        }//end of contact

        //Empty constructor
        public Person()
        {
            IdNumber = 1;
            FirstName = "John";
            LastName = "Human";
            Contact = new ContactInfo("Email@email.ca", "780-555-8246");
        }//End of person

        public override string ToString()
        {
            return $"Id: {IdNumber}\nName: {FirstName}\n{LastName}\nContact:{Contact}";
        }//End of Tostring


    }//eoc
}//eon
