﻿/*

    +-----------------------------------------------------------------------------------------------+
    | Instructor                                                                                    |
    +-----------------------------------------------------------------------------------------------+
    | - officeNumber : String                                                                       |   
    | + OfficeNumber : String                                                                       |
    +-----------------------------------------------------------------------------------------------+
    | + Instructor(IDNumber : Integer, LastName: String, FirstName : String, Contact : ContactInfo, |
    |              OfficeNumber : String)                                                           |
    | + ToString() : String                                                                         |
    +-----------------------------------------------------------------------------------------------+
 */

namespace InheritanceDemo.Classes
{
    public class Instructor : Person
    {
        private string _officeNumber;

        public string OfficeNumber
        {
            get { return _officeNumber; }
            set
            {
                if (value.Length >= 1)
                {
                    _officeNumber = value;
                }
                else
                {
                    throw new Exception("Invalid Office Number");
                }
            }
        }//End of OfficeNumber
        public Instructor(int id, string lastName, string firstName, ContactInfo contact, string officeNumber)
        {
            IdNumber = id;
            LastName = lastName;
            FirstName = firstName;
            Contact = contact;
            OfficeNumber = officeNumber;
        }//End of Greedy constructor

        public override string ToString()
        {
            return $"ID: {IdNumber}, Name: {LastName}, {FirstName}, Contact: {Contact}, Office Number: {OfficeNumber}";
        }//End of override
    }//eoc
}//eon
