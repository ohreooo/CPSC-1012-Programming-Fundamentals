﻿using System.Globalization;

namespace OOP_ObjectArray
{
    internal class Program
    {
        //class level variables
        static string headerColumn1,
                headerColumn2;
        static void Main()
        {
            //declare variables
            const int PhysicalSize = 25;
            const string PathAndFile = @"F:\CPSC1012\VisualStudio2022Code\InClass\OOP\OOP-Intro\NamesAndGrades.csv";

            StudentData[] students = new StudentData[PhysicalSize]; //object array
            int logicalSize,
                grade = 0;
            string name = "";

            try
            {
                if (File.Exists(PathAndFile))
                {
                    //load the array from the file
                    logicalSize = LoadArrayFromFile(students, PhysicalSize, PathAndFile);

                    //display the contents of the array
                    DisplayArray(students, logicalSize);

                    //add an element to the array
                    logicalSize = AddToArray(students, logicalSize, "Allan Anderson", 50);

                    DisplayArray(students, logicalSize);

                    //write the odified array to the file
                    WriteArrayToFile(students, logicalSize, PathAndFile);

                    DisplayArray(students, logicalSize);
                }
                else
                {
                    Console.WriteLine($"The file, {PathAndFile}, does not exist!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static int LoadArrayFromFile(StudentData[] students, int size, string filename)
        {
            int grade,
                logicalSize = -1;
            string name,
                input;
            StreamReader reader = null;
            try
            {
                reader = File.OpenText(filename);
                while ((input = reader.ReadLine()) != null && logicalSize < size)
                {
                    string[] parts = input.Split(',');
                    if (logicalSize < 0)
                    {
                        headerColumn1 = parts[0];
                        headerColumn2 = parts[1];
                    }
                    else
                    {
                        name = parts[0];
                        grade = int.Parse(parts[1]);
                        //store this data as an object in the array
                        students[logicalSize] = new StudentData(name, grade);
                    }
                    logicalSize++;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error: {ex.Message}");
            }
            finally
            {
                reader.Close();
            }
            return logicalSize;
        }

        static void DisplayArray(StudentData[] students, int size)
        {
            Console.WriteLine($"{headerColumn1, -20}{headerColumn2, -5}");
            for (int index = 0; index < size; index++)
            {
                Console.WriteLine($"{students[index].Name,-20}{students[index].Grade, 3}");
            }
        }

        static int AddToArray(StudentData[] students, int size, string name, int grade)
        {
            students[size] = new StudentData(name, grade);
            return ++size;
        }

        static void WriteArrayToFile(StudentData[] students, int size, string filename)
        {
            string output;
            StreamWriter writer = null;
            try
            {
                writer = File.CreateText(filename);
                output = $"{headerColumn1},{headerColumn2}";
                writer.WriteLine(output);
                for (int index = 0; index < size; index++)
                {
                    output = $"{students[index].Name},{students[index].Grade}";
                    writer.WriteLine(output);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error: {ex.Message}");
            }
            finally
            {
                writer.Close();
            }
        }
    }
 }
