﻿namespace UnitTestingClasses
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Unit Testing Demo - Run the Test Explorer");
            Console.ReadLine();
        }
    }
}

