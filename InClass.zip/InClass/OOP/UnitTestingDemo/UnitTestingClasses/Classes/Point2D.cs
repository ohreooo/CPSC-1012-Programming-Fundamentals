﻿namespace UnitTestingClasses.Classes
{
    public class Point2D
    {
        //private member fields
        private double _xValue;
        private double _yValue;

        //public properties - using auto-implemented properties as any number is valid
        public double XValue
        {
            get { return _xValue; }
            set { _xValue = value; }
        }//end of XValue

        public double YValue
        {
            get { return _yValue; }
            set { _yValue = value; }
        }//end of YValue

        //constructor
        public Point2D(double xValue, double yValue)
        {
            XValue = xValue;
            YValue = yValue;
        }//end of Point2D

        //Class Methods
        public Point2D MidPoint(Point2D pointB)
        {
            return new Point2D(0.5 * (XValue + pointB.XValue), 0.5 * (YValue + pointB.YValue));
        }//end of MidPoint

        public double SegmentLength(Point2D pointB)
        {
            return Math.Sqrt(Math.Pow(pointB.XValue - XValue, 2) + Math.Pow(pointB.YValue - YValue, 2));
        }//end of SegmentLength
    }
}
