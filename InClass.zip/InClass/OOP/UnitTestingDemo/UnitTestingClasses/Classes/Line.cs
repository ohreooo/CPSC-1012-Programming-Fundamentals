﻿namespace UnitTestingClasses.Classes
{
    public class Line
    {
        private Point2D _pointA;
        private Point2D _pointB;

        public Point2D PointA
        {
            get { return _pointA; }
            set { _pointA = value; }
        }//end of PointA

        public Point2D PointB
        {
            get { return _pointB; }
            set { _pointB = value; }
        }//end of PointB

        public Line(Point2D pointA, Point2D pointB)
        {
            PointA = pointA;
            PointB = pointB;
        }

        public double Slope()
        {
            return (PointA.YValue - PointB.YValue) / (PointA.XValue - PointB.XValue);
        }//end of Slope

        public double YIntercept()
        {
            return PointA.YValue - (Slope() * PointA.XValue);
        }//end of YIntercept

        public override string ToString()
        {
            return $"y = {Slope()}x + {YIntercept()}";
        }//end of ToString
    }
}
