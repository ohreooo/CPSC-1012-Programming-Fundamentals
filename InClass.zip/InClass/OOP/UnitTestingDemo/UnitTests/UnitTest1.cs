using System.Security.Cryptography.X509Certificates;
using UnitTestingClasses.Classes;

namespace UnitTests
{
    public class Tests
    {
        [Test,
            TestCase(0, 0, 3, 4, 5), TestCase(4, 6, 4, 6, 0)]
        public void TestSegmentLength(double aX, double aY, double bX, double bY, double expected)
        {
            //setup
            Point2D pointA = new Point2D(aX, aY);
            Point2D pointB = new Point2D(bX, bY);

            //act
            double actual = pointA.SegmentLength(pointB);

            //assert
            Assert.AreEqual(expected, actual);
        }//end of TestSegmentLength

        [Test, TestCase(3, 4, 6, 9, 4.5, 6.5), TestCase(4, 3, 6, 9, 5, 6), TestCase(4, 5, 4, 5, 4, 5)]
        public void TestMidPoint(double aX, double aY, double bX, double bY, double expectedX, double expectedY)
        {
            //setup
            Point2D pointA = new Point2D(aX, aY);
            Point2D pointB = new Point2D(bX, bY);

            //act
            Point2D actual = pointA.MidPoint(pointB);

            //assert
            Assert.AreEqual(expectedX, actual.XValue);
            Assert.AreEqual(expectedY, actual.YValue);
        }//end of TestMidPoint

        [Test, TestCase(0, 0, 4, 3, 0.75), TestCase(0, 0, 3, 4, 1.3333), TestCase(3, 4, 6, 4, 0), TestCase(3, 4, 3, 6, double.NegativeInfinity)]
        public void TestSlope(double aX, double aY, double bX, double bY, double expected)
        {
            //setup
            Point2D pointA = new Point2D(aX, aY);
            Point2D pointB = new Point2D(bX, bY);
            Line line = new Line(pointA, pointB);

            //act
            double actual = line.Slope();

            //assert
            Assert.AreEqual(expected, Math.Round(actual, 4));
        }// end of TestSlope

        [Test, TestCase(0, 0, 3, 4, 0)]
        public void TestIntercept(double aX, double aY, double bX, double bY, double expected)
        {
            //setup
            Line line = new Line(new Point2D (aX, aY), new Point2D (bX, bY));

            //act
            double actual = line.YIntercept();

            //assert
            Assert.AreEqual(expected, Math.Round(actual, 4));
        }
    }
}