﻿using CarClassDemo.Classes;
using System.Transactions;

/* 
Purpose:		To demonstrate a class with multiple class properties	
                CarClassDemo.EngineType.cs
                CarClassDemo.TransmissionType.cs
                CarClassDemo.Car.cs
Input:			data to build a car	
Output:			car data 
Written By: 	 
Last Modified:	 
*/

namespace CarClassDemo
{
    class Program
    {
        static void Main()
        {
            Setup();
			try
			{
                //1. Create a new Car
                Car myCar = CreateCar();

                //2. Display the new Car
                Console.WriteLine(myCar);
			}
			catch (Exception ex)
			{
				Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);
                Console.ForegroundColor = ConsoleColor.Black;
			}

        }//eom

        #region Your Methods Go Here
        static Car CreateCar()
        {
            string make,
                model;
            int cylinders,
                horsepower,
                gears;
            double size;
            //declaring enum variable
            TransmissionType.TypeName type;
            Car myCar;
            try
            {
                Console.WriteLine("Make and Model");
                make = GetSafeString($"{"Enter the make: ",31}");
                model = GetSafeString($"{"Enter the model: ",31}");
                Console.WriteLine("Engine Specifications");
                size = GetSafeDouble($"{"Enter engine size in Litres: ",31}");
                cylinders = GetSafeInt($"{"Enter number of cylinders: ",31}");
                horsepower = GetSafeInt($"{"Enter engine horsepower: ",31}");

                //Create the Engine
                EngineType engine = new EngineType(size, cylinders, horsepower);
                Console.WriteLine("Transmission Specifications");
                gears = GetSafeInt($"{"Enter number of forward gears: ",31}");
                type = GetTransmissionType();

                //Create the Transmission
                TransmissionType transmission = new TransmissionType(type, gears);
                myCar = new Car(make, model, engine, transmission);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
            return myCar;
        }//end of CreateCar
		
		static TransmissionType.TypeName GetTransmissionType()
		{
            int option;
            TransmissionType.TypeName type;
            do
            {
                DisplayTransmissionTypeMenu();
                option = GetSafeInt("Option: ");
                switch (option)
                {
                    case 1:
                        type = TransmissionType.TypeName.Automatic;
                        break;
                    case 2:
                        type = TransmissionType.TypeName.Manual;
                        break;
                    case 3:
                        type = TransmissionType.TypeName.CVT;
                        break;
                    case 4:
                        type = TransmissionType.TypeName.Electric;
                        break;
                    default:
                        Console.WriteLine("Invalid option...try again");
                        type = TransmissionType.TypeName.none;
                        break;
                }
            } while (option < 1 || option > 4);
            return type;
		}//end of GetTransmissionType
		
		static void DisplayTransmissionTypeMenu()
        {
            Console.WriteLine("Select Transmission Type");
            Console.WriteLine("\t1. Automatic");
            Console.WriteLine("\t2. Manual");
            Console.WriteLine("\t3. CVT");
            Console.WriteLine("\t4. Electric");
        }//end of DisplayTransmissionTypeMenu


        #endregion

        #region Provided Methods
        static void Setup()
        {
            Console.Title = "Car Class Demo with Enum";
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
        }//end of Setup

        static int GetSafeInt(string prompt)
        {
            int number = 1;
            bool isValid = false;
            do
            {
                try
                {
                    Console.Write("{0,20}", prompt);
                    number = int.Parse(Console.ReadLine());
                    if (number >= 0)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("ERROR: Invalid number ... try again");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("ERROR: Invalid number ... try again");
                }
            } while (!isValid);
            return number;
        }//end of getSafeInt

        static double GetSafeDouble(string prompt)
        {
            double number = 1;
            bool isValid = false;
            do
            {
                try
                {
                    Console.Write("{0,20}", prompt);
                    number = double.Parse(Console.ReadLine());
                    if (number >= 0)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("ERROR: Invalid number ... try again");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("ERROR: Invalid number ... try again");
                }
            } while (!isValid);
            return number;
        }//end of getSafeDouble

        static string GetSafeString(string prompt)
        {
            string name;
            bool isValid = false;
            do
            {
                Console.Write("{0,20}", prompt);
                name = Console.ReadLine();
                if (name.Length >= 2)
                {
                    isValid = true;
                }
                else
                {
                    Console.WriteLine("ERROR: Name is not valid");
                }
            } while (!isValid);
            return name;
        }//end of GetSafeString
        #endregion
    }//eoc
}//eon
