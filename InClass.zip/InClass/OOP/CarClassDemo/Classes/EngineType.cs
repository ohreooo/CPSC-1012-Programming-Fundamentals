﻿/*
    +---------------------------------------------------------------------------------------------+
    | EngineType                                                                                  |
    +---------------------------------------------------------------------------------------------+
    | - size : Double                                                                             |
    | - cylinders : Integer                                                                       |
    | - horsepower : Integer                                                                      |
    | + Size : Double                                                                             |
    | + Cylinders : Integer                                                                       |
    | + Horsepower : Integer                                                                      |
    +---------------------------------------------------------------------------------------------+
    | + EngineType(Size : Double, Cylinders : Integer, Horsepower : Integer)                      |
    | + ToString() : String                                                                       |
    +---------------------------------------------------------------------------------------------+
 */
namespace CarClassDemo.Classes
{
    public class EngineType
    {
        //private member field(s)
        private double _size;
        private int _cylinders;
        private int _horsepower;

        //public Accessor(s) and Mutator(s)
        public double Size
        {
            get { return _size; }
            set
            {
                if(value >= 1.0)
                {
                    _size = value;
                }
                else
                {
                    throw new Exception("Invalid Engine Size");
                }
            }
        }// end of Size

        public int Cylinders
        {
            get { return _cylinders; }
            set
            {
                if ((value >= 4 && value <= 12 && value % 2 == 0) || value == 0) //0 for an electric car
                {
                    _cylinders = value;
                }
                else
                {
                    throw new Exception("Invalid Engine Cylinders");
                }
            }
        }//end of Cylinders

        public int Horsepower
        {
            get { return _horsepower; }
            set
            {
                if(value > 0)
                {
                    _horsepower = value;
                }
                else
                {
                    throw new Exception("Invalid Engine Horespower");
                }
            }
        }//end of Horespower

        //constructor(s)
        public EngineType(double size, int cylinders, int horsepower)
        {
            Size = size;
            Cylinders = cylinders;
            Horsepower = horsepower;
        }//end of EngineType

        //class method(s)
        public override string ToString()
        {
            return $"{Cylinders} cylinder, {Size:0.0}L, {Horsepower} bhp engine"; 
        }//end of ToString
    }//eoc
}//eon