﻿/*
    +---------------------------------------------------------------------------------------------+
    | TransmissionType                                                                            |
    +---------------------------------------------------------------------------------------------+
    | - gears : Integer                                                                           |
    | - typeName : String                                                                         |
    | + Gears : Integer                                                                           |
    | + TypeName : String                                                                         |
    +---------------------------------------------------------------------------------------------+
    | + TransmissionType (Gears : Integer, TypeName : String)                                     |
    | + ToString() : String                                                                       |
    +---------------------------------------------------------------------------------------------+
 */
namespace CarClassDemo.Classes
{
    public class TransmissionType
    {
        //enum
        public enum TypeName
        {
            Automatic,
            Manual,
            CVT,
            Electric,
            none
        }
        //private member field(s)
        private int _gears;


        //public Accessor(s) and Mutator(s)
        public int Gears
        {
            get { return _gears; }
            set
            {
                if(value > 0)
                {
                    _gears = value;
                }
                else
                {
                    throw new Exception("Invalid Transmission Gears");
                }
            }
        }//end of Gears

        public TypeName Type; // do not need anything else as the enum is type-safe

        //constructor(s)
        public TransmissionType(TypeName type, int gears)
        {
            Type = type;
            Gears = gears;
        }//end of TransmissionType

        //class method(s)
        public override string ToString()
        {
            return $"{Gears} speed {Type} transmission";
        }//end of ToString

    }//eoc
}//eon
