﻿/*
   +---------------------------------------------------------------------------------------------+
   | Car                                                                                         |
   +---------------------------------------------------------------------------------------------+
   | - make : String                                                                             |
   | - model : String                                                                            |
   | - Engine: EngineType                                                                        |
   | - Transmission : TransmissionType                                                           |
   | + Make : String                                                                             |
   | + Model : String                                                                            |
   | + Engine : EngineType                                                                       |
   | + Transmission : TransmissionType                                                           |
   +---------------------------------------------------------------------------------------------+
   | + Car (Make : String, Model : String, Engine : EngineType, Transmission : TransmissionType) |
   | + ToString() : String                                                                       |
   +---------------------------------------------------------------------------------------------+
 */
namespace CarClassDemo.Classes
{
    public class Car
    {
        //private member field(s)
        private string _make;
        private string _model;
        private EngineType _engine;
        private TransmissionType _transmission;

        //public Accessor(s) and Mutator(s)
        public string Make
        {
            get { return _make; }
            set
            {
                if (value.Length >= 2)
                {
                    _make = value;
                }
                else
                {
                    throw new Exception("Invalid Car Make");
                }
            }
        }

        public string Model
        {
            get { return _model; }
            set
            {
                if (value.Length >= 2)
                {
                    _model = value;
                }
                else
                {
                    throw new Exception("Invalid Car Model");
                }
            }
        }

        public EngineType Engine
        {
            get { return _engine; }
            set { _engine = value; }
        }

        public TransmissionType Transmission
        {
            get { return _transmission; }
            set { _transmission = value; }
        }
        //constructor(s)
        public Car(string make, string model, EngineType engine, TransmissionType transmission)
        {
            Make = make;
            Model = model;
            Engine = engine;
            Transmission = transmission;
        }
        //class method(s)
        public override string ToString()
        {
            return $"{Make} {Model}\n{Engine}\n{Transmission}";
        }//eotostring
    }//eoc
}//eon
