﻿//Purpose: Demonstrate creating & calling methods => get an absolute value
//Input: number
//Output: absoluteValue
//Author: Kaiden Flaig
//Date: Oct 12, 2022

Setup();
int number = GetAbsoluteValue();
Console.WriteLine(number);
Console.ReadLine();

//Setup() - method to setup console.
static void Setup()
{
    Console.Title = "Get Absolute Value";
    Console.Clear();
}//end of Setup

//GetSafeInt(string) - method to get an integer from a string above the minimum value, validation loop.
static int GetSafeInt(string prompt, int minValue)
{
    bool isValid = false;
    int number;
    do
    {
        try
        {
            Console.Write(prompt);
            number = int.Parse(Console.ReadLine());

            if (number > minValue)
            {
                isValid = true;
            }
            else
            {
                Console.WriteLine("invalid range!");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("invalid integer!");
            number = -1;
        }
    } while (!isValid);

    return number;
}//end of GetSafeInt

//GetAbsoluteValue() - method to get absolute value from an integer. Int is provided by the GetSafeInt() method.
static int GetAbsoluteValue()
{
    int number = GetSafeInt("please enter an integer: ", 0);
    int absolute = Math.Abs(number);
    return absolute;
}//end of GetAbsoluteValue}