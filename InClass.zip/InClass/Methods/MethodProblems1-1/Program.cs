﻿namespace MethodProblems1_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int age;
            double price;

            //display the menu
            DisplayMenu();

            //input age
            age = GetSafeInt("Enter age: ");

            price = GetTicketPrice(age);

            Console.Write($"The ticket price is {price:c}");

        }

        static double GetTicketPrice(int age)
        {
            double num1;
            if (age <= 6)
            {
                num1 = 0;

            }

            else if (age <= 17)
            {
                num1 = 9.80;

            }
            else if (age <= 54)
            {
                num1 = 11.35;

            }
            else
            {
                num1 = 10;

            }
            return num1;
        }

        static int GetSafeInt(string prompt)
        {
            bool isValid = false;
            int number;
            int minValue = 0;
            do
            {
                try
                {
                    Console.Write(prompt);
                    number = int.Parse(Console.ReadLine());

                    if (number > minValue)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("invalid range!");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("invalid integer!");
                    number = -1;
                }
            } while (!isValid);

            return number;
        }//end of GetSafeInt
        static void DisplayMenu()
        {
            Console.WriteLine("Select one of the following age groups");
            Console.WriteLine("Children 6 and under = Free");
            Console.WriteLine("Children 7-17: $9.80");
            Console.WriteLine("Age 18-54: $11.35");
            Console.WriteLine("Age 55+: $10.00");
        }
    }
}