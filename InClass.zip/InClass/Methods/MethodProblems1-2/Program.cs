﻿namespace MethodProblems1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int studentGrade;
            string nameStudent;
            char letterGrade;


            nameStudent = GetStudentName("Enter student's name: ");
            studentGrade = GetSafeInt("Enter student's mark: ");
            letterGrade = LetterGradeFromMark(studentGrade);

            Console.Write($"{nameStudent}'s letter grade is {letterGrade}");
        }//end of Main

        static string GetStudentName(string prompt)
        {
            bool isValid = false;
            string studentName = "";

            do
            {

                Console.Write(prompt);
                studentName = Console.ReadLine();

                if (studentName.Length >= 3 && studentName != "   ")
                {
                    isValid = true;
                }
                else
                {
                    Console.WriteLine("invalid name!");
                }

            } while (!isValid);

            return studentName;
        }
        static int GetSafeInt(string prompt)
        {
            bool isValid = false;
            int number = 0;
            const int minValue = 0;
            const int maxValue = 100;
            do
            {
                try
                {
                    Console.Write(prompt);
                    number = int.Parse(Console.ReadLine());

                    if (number >= minValue && number <= maxValue)
                    {
                        isValid = true;
                    }
                    else
                    {
                        Console.WriteLine("invalid range!");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("invalid integer!");
                }
            } while (!isValid);

            return number;
        }//end of GetSafeInt

        static char LetterGradeFromMark(int grade)
        {
            char message;
            if (grade <= 49)
            {
                message = 'F';
            }
            else if (grade <= 69)
            {
                message = 'D';
            }
            else if (grade <= 79)
            {
                message = 'C';
            }
            else if (grade <= 89)
            {
                message = 'B';
            }
            else
            {
                message = 'A';
            }

            return message;
        }
    }
}