﻿/*
 * Purpose: Demonstate class level methods using a simple Die class
 * Input: Die.cs
 * Output: Display wins, losses, ties, games played
 * Author: Howard Cueva
 * Date: Nov 9, 2022
 */


namespace DieGame
{
    internal class Program
    {
        static void Main()
        {
            try
            {
                // declare variables
                Die computerDie1 = new Die(),
                    computerDie2 = new Die(),
                    playerDie1 = new Die(),
                    playerDie2 = new Die();

                int gamesPlayed = 0,
                    playerWins = 0,
                    computerWins = 0,
                    playerRoll,
                    computerRoll,
                    ties = 0;

                string message;

                char rollAgain;

                // game loop
                do
                {
                    // roll the dice
                    computerDie1.Roll();
                    computerDie2.Roll();
                    playerDie1.Roll();
                    playerDie2.Roll();

                    // add the dice
                    playerRoll = playerDie1.AddDie(playerDie2);
                    computerRoll = computerDie1.AddDie(playerDie2);

                    // display the dice
                    DisplayRoll(playerDie1, playerDie2, "Player");
                    DisplayRoll(computerDie1, computerDie2, "Computer");

                    // determine winner or a tie
                    if (playerRoll > computerRoll)
                    {
                        playerWins++;
                        message = "Player Wins";
                    }
                    else if (computerRoll > playerRoll)
                    {
                        computerWins++;
                        message = "Computer Wins";
                    }
                    else
                    {
                        ties++;
                        message = "It's a tie";
                    }
                    gamesPlayed++;
                    Console.WriteLine(message);

                    // prompt to roll again
                    Console.Write("\nRoll again (Y): ");
                    rollAgain = char.Parse(Console.ReadLine().ToUpper().Substring(0, 1));

                } while (rollAgain == 'Y');

                // Display the game summary
                Console.WriteLine($"\n{gamesPlayed} games played: Player Wins: {playerWins}, Computer Wins:{computerWins}, and Ties:{ties}");
            }
            catch (Exception)
            {
                throw;
            }


            

            Console.ReadLine();
        }// end of Main

        static void DisplayRoll(Die die1, Die die2, string player)
        {
            Console.WriteLine ($"{player, 8}'s roll was: {die1.Facevalue} and {die2.Facevalue}");
        }

    }
}