﻿/*
 * Purpose:Find the sum of the squares of the integers from 1 to mySquare, where mySquare is input by the user, e.g., user enters 4 then return 1x1 + 2x2 + 3x3 + 4x4 = 30.
 * 
 * Input: mySquare
 * 
 * Output: sum/total
 * 
 * Author: Marc Trillanes
 * 
 * Date:September 26, 2022

*/
namespace mySquare
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //declare variables
            int mySquare = 0,
                sum,
                count;
            bool isValid;
            char choice = ' ';
            // if they want to do the method again with another number
            do
            {
                //validation loop
                do
                {
                    isValid = false;
                    try
                    {
                        //reset
                        
                        // prompt for mySquare
                        Console.Write("\nEnter the value for mySquare: ");
                        mySquare = int.Parse(Console.ReadLine());
                        //range check
                        if (mySquare > 0 && mySquare < 11)
                        {
                            isValid = true;
                        }
                        else
                        {
                            Console.WriteLine("Number entered not between 1 and 10 inclusive...Please try again.");
                        }
                    }
                    catch (Exception)
                    {
                        Console.Write("Error: Not a valid number!...Please try again.");
                    }
                } while (!isValid);
                count = 1;
                sum = 0;
                while (count <= mySquare)
                {
                    sum += count * count;
                    //start the output
                    Console.Write($"{count}x{count}");

                    //once the value input is reached, get the total instead of adding more
                    if (count == mySquare)
                    {
                        Console.Write(" = ");
                    }
                    else
                    {
                        Console.Write(" + ");
                    }
                    count++;
                }

                Console.WriteLine($"{sum}");
                Console.Write("\nAnother try? (Y/N): ");
                choice = char.Parse(Console.ReadLine().ToLower().Substring(0, 1));
            } while (choice == 'y');
           



            //since it's Console.Write for the if statement, the sum will appear on the same line as the calculation
            

            Console.ReadLine();
        }
    }
}