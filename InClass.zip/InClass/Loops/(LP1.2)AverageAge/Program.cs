﻿/*
 * Purpose: Input a list of positive numbers from the user and then calculate and display the average age. Use the input of the number zero (i.e., 0) to stop prompting for numbers.
 * 
 * Input: age
 * 
 * Output: average
 * 
 * Author: Marc Trillanes
 * 
 * Date: September 26, 2022

*/
namespace AverageAge
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //declare variables
            int age,
                count = 1;
            double average = 0;

            //input age
            Console.Write("Enter a positive number or 0 to exit: ");
            age = int.Parse(Console.ReadLine());

            //loop
            //add age to sum
            //input age
            //increment count if age !=0
            while (age != 0)
            {
                average += age;
                Console.Write("Enter a positive number or 0 to exit: ");
                age = int.Parse(Console.ReadLine());
                //if 0 is the input, no more numbers can be added to the list and the average will be calculated
                if (age != 0)
                {
                    count++;
                }
            }

            //display average
            average /= count;
            Console.WriteLine($"The average is {average:f1}");


            Console.ReadLine();
        }
    }
}