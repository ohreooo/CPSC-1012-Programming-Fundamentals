﻿namespace LoopProblems1_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string numberInput;
            int sum = 0,
                length,
                start = 0;

            Console.Write("Enter a positive whole number: ");
            numberInput = Console.ReadLine();

            length = numberInput.Length;

            while (start < numberInput.Length)
            {
                sum += int.Parse(numberInput.Substring(start, 1));
                Console.WriteLine($"{sum}");
            }
        }
    }
}