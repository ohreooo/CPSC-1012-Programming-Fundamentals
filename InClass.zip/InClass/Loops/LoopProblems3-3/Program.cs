﻿namespace LoopProblems3_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char serviceOption = ' ',
                additionalPackage = ' ';
            double hours = 0,
                bill = 0;
            do
            {
                Console.WriteLine("Select the service package from the options below: ");
                Console.WriteLine("\tA - $9.95 per month for up to 10 hours; additional hours are billed at $2.00 per hour");
                Console.WriteLine("\tB - $13.95 per month for up to 20 hours; additional hours are billed at $1.00 per hour");
                Console.WriteLine("\tC - $19.95 per month for unlimited hours");
                Console.Write("Option: ");
                serviceOption = char.Parse(Console.ReadLine().ToUpper().Substring(0, 1));

                switch (serviceOption)
                {
                    case 'A':
                        Console.Write("Enter hours used: ");
                        hours = int.Parse(Console.ReadLine());
                        if (hours > 10)
                        {
                            bill = 9.95 + ((hours - 10) * 2);
                        }
                        else
                        {
                            bill = 9.95;
                        }
                        break;
                    case 'B':
                        Console.Write("Enter hours used: ");
                        hours = int.Parse(Console.ReadLine());
                        if (hours > 20)
                        {
                            bill = 13.95 + (hours - 20);
                        }
                        else
                        {
                            bill = 13.95;
                        }
                        break;
                    case 'C':
                        bill = 19.95;
                        break;
                    default:
                        Console.WriteLine("Invalid Selection");
                        break;
                }
                Console.WriteLine($"The bill is {bill:c}");
                Console.Write("\nAnother Package (Y/N): ");
                additionalPackage = char.Parse(Console.ReadLine().ToLower().Substring(0, 1));
            } while (additionalPackage == 'y') ;
        }  
    }
}