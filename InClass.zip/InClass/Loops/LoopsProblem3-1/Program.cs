﻿namespace LoopsProblem3_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            double initialPopulation,
                growthRate = 0,
                dayCount = 1;
            double finalPopulation = 0;

            //input age
            Console.Write("Enter initial population: ");
            initialPopulation = double.Parse(Console.ReadLine());
            Console.Write("Enter growth rate: ");
            growthRate = double.Parse(Console.ReadLine());
            growthRate = growthRate / 100;
            //loop
            //add age to sum
            //input age
            //increment count if age !=0
            for(; dayCount < 11; dayCount++)
            {
                finalPopulation = initialPopulation * (Math.Pow(Math.E, (growthRate * dayCount)));
                Console.WriteLine($"Day {dayCount} population is {finalPopulation:f0}");

            }

            Console.ReadLine();
        }
    }
}