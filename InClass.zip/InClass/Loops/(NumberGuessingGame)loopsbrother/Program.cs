﻿/*
 * Purpose: guess a randomly generated number until you get the correct number
 * 
 * Input: guess
 * 
 * Output: # of guesses until the correct number is found
 * 
 * Author: Marc Trillanes
 * 
 * Date: September 26, 2022

*/
namespace loopsbrother
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //set random number
            Random random = new Random();

            //declare variables
            int guess,
                computerNumber,
                count = 0;

            //input
            Console.Write("Guess a number between 1 and 100 inclusive: ");
            guess = int.Parse(Console.ReadLine());

            //generate a number between 1-100 (inclusive)
            computerNumber = random.Next(1, 101);

            //loop the guessing structure until the correct one is found
            while (guess != computerNumber)
            {
                count++;

                if (guess > computerNumber)
                {
                    Console.WriteLine($"Your guess, {guess}, is too high");
                }
                else
                {
                    Console.WriteLine($"Your guess, {guess}, is too low");
                }
                //change for the test to avoid an infinite loop.
                Console.Write("Guess a number between 1 and 100 inclusive: ");
                guess = int.Parse(Console.ReadLine());
            }

            //display results
            Console.WriteLine($"You chose wisely but had {count} incorrect guesses.");

            Console.ReadLine();
        }
    }
}