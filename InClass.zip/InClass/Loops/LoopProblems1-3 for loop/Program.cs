﻿namespace LoopProblems1_3_for_loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string number;
            int count;

            Console.Write("Enter the value of a number: ");
            number = Console.ReadLine();

            for (count = number.Length - 1; count >= 0; count--)
            {
                Console.WriteLine($"{number.Substring(count,1)}");
            }
        }
    }
}