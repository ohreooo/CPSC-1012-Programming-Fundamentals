﻿namespace LoopProblems3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string userInput = "";
            char letterToCount;
            int appearanceCount = 0,
                stringCount = 0;

            Console.Write("Enter some text (can be anything): ");
            userInput = Console.ReadLine();
            Console.Write("Enter a character to find the count of: ");
            letterToCount = char.Parse(Console.ReadLine().Substring(0, 1));
            for(; stringCount != userInput.Length - 1; stringCount++)
            {
                if (letterToCount == char.Parse(userInput.Substring(stringCount, 1)))
                {
                    appearanceCount++;
                }
            }
            Console.WriteLine($"The character, {letterToCount}, was found {appearanceCount} times");
        }
    }
}