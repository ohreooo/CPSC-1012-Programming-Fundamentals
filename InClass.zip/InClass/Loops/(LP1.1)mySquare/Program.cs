﻿/*
 * Purpose:Find the sum of the squares of the integers from 1 to mySquare, where mySquare is input by the user, e.g., user enters 4 then return 1x1 + 2x2 + 3x3 + 4x4 = 30.
 * 
 * Input: mySquare
 * 
 * Output: sum/total
 * 
 * Author: Marc Trillanes
 * 
 * Date:September 26, 2022

*/
namespace mySquare
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //declare variables
            int mySquare,
                sum = 0,
                count = 1;

            //input
            Console.Write("Enter the value for mySquare: ");
            mySquare = int.Parse(Console.ReadLine());

            //loop;
            //add to sum (count*2)
            //display
            while (count <= mySquare)
            {
                sum += count * count;
                //start the output
                Console.Write($"{count}x{count}");

                //once the value input is reached, get the total instead of adding more
                if (count == mySquare)
                {
                    Console.Write(" = ");
                }
                else
                {
                    Console.Write(" + ");
                }
                count++;
            }
            //since it's Console.Write for the if statement, the sum will appear on the same line as the calculation
            Console.WriteLine($"{sum}");

            Console.ReadLine();
        }
    }
}