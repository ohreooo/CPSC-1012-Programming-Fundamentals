﻿/*
    Purpose: Create a simple calculator

    Input: Number 1, Number 2

    Output: Sum, Difference (1-2), Product, Quotient (1/2)

    Author: Reonel Duque

    Date: September 7, 2022
*/

namespace ExampleProblem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            double number1,
                number2,
                sum,
                difference,
                product,
                quotient;

            // input 2 numbers
            Console.Write("Input the first number: "); //Write outputs a text in a line without starting a new line, WriteLine outputs a text in a line and starts a new line
            number1 = double.Parse(Console.ReadLine());

            Console.Write("Input the second number: ");
            number2 = double.Parse(Console.ReadLine());

            //add, subtract, multiply, divide
            sum = number1 + number2;

            difference = number1 - number2;

            product = number1 * number2;

            //quotient = Math.Round(number1 / (number2 * 1.0), 4); //second argument is decimal places
            quotient = (number1 * 1.0) / number2;
               
            //display results
            Console.WriteLine("The sum is " + sum); // concatenation for output, decimal is much complicated, prefer the direct method
            Console.WriteLine("The difference is {0:0.0000}", difference); // parameterized:shows decimal places
            Console.WriteLine($"The product is {product}"); // direct
            Console.WriteLine($"The quotient is {quotient:f4}"); //f4 shows 4 decimal places, preffered

        }
    }
}