﻿/*
 Purpose: Demonstrate some of the important String class
 Input: N/A
 Output: 
 Author: Reonel Duque
 Date: September 12, 2022
*/

namespace StringDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // declare variables & constants
            const string Name = "Programming Fundamentals";
            string stringPart;
            int length;
            bool contains;

            // .ToUpper() - converts all letters to uppercase
            // .ToLower() - converts all letters to lowercase
            stringPart = Name.ToUpper();
            Console.WriteLine(stringPart);

            // Pick parts of the string using .Substring()
            // .Substring(startIndex) where startIndex is an int
            // .Substring(startIndex, length)
            stringPart = Name.Substring(12);
            Console.WriteLine(stringPart);

            stringPart = Name.Substring(11);
            Console.WriteLine(stringPart);

            stringPart = Name.Substring(12, 3);
            Console.WriteLine(stringPart);

            // .Length property - properties do not have () at the end, methods do
            length = Name.Length;
            Console.WriteLine(length);

            // .Contains()
            contains = Name.Contains("fun");
            Console.WriteLine(contains);

            contains = Name.ToUpper().Contains("FUN");
            Console.WriteLine(contains);
            Console.WriteLine(stringPart.Equals("Fun"));
            Console.WriteLine(stringPart.Equals(Name));

            /*
             * Two string functions you may find useful are :
             *      stringVariable.Compare()
             *      stringVariable.Equals(someString)
             */

            Console.ReadLine();
        }
    }
}
