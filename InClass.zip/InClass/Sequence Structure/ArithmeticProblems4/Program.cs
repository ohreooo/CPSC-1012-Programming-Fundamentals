﻿/*
    Purpose: Calculate the sum of a 3 digit whole number

    Input: Three digit whole number

    Output: Sum of the three digit whole number

    Author: Reonel Duque

    Date: September 9, 2022
*/

namespace ArithmeticProblems3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            int inputNumber,
                digit1,
                digit2,
                digit3,
                sum;

            // input three digit number
            Console.Write("Enter a 3 digit whole number: ");
            inputNumber = int.Parse(Console.ReadLine());

            //extracting digits
            digit1 = (inputNumber / 100);
            digit2 = (inputNumber % 100) / 10;
            digit3 = (inputNumber % 10);

            //calculating sum
            sum = digit1 + digit2 + digit3;

            //display results
            Console.WriteLine($"The sum of the digits is {sum}"); //dollar sign is string literal, converting "sum" to a string.

            //keeps the console window open
            Console.ReadLine();

        }
    }
}