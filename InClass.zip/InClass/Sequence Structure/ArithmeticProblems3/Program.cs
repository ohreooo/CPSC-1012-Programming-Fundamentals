﻿/*
    Purpose: Calculate average of three real numbers

    Input: Number 1, Number 2, Number 3

    Output: Average of the Three Input Numbers

    Author: Reonel Duque

    Date: September 9, 2022
*/

namespace ArithmeticProblems3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables and constants
            double number1,
                number2,
                hypotenuse;

            // input the base and height
            Console.Write("Enter the height of the triangle: ");
            number1 = double.Parse(Console.ReadLine());

            Console.Write("Enter the base of the triangle: ");
            number2 = double.Parse(Console.ReadLine());

            //calculating for hypotenuse
            hypotenuse = Math.Sqrt((number1 * number1) + (number2 * number2));

            //display results
            //Console.WriteLine("The average of {0}, {1}, and {2} is {3:f2}", number1, number2, number3, average);
            Console.WriteLine($"The hypotenuse is {hypotenuse:f13}"); // <-- called "string literals"

            //keeps the console window open
            Console.ReadLine();

        }
    }
}