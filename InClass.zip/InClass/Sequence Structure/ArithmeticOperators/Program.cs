﻿/*
    Purpose: Demonstrate basic arithmetic in C#

    Input: N/A

    Output: The results of various arithmetic operations

    Author: Reonel Duque

    Date: September 12, 2022
*/

namespace ArithmeticOperators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables and constants
            int a = 2, // "=" is an assignment operator
                b = 3,
                e = 4,
                f = 5;
            double c = 4,
                d = 5;

            // display original values
            Console.WriteLine($"a = {a}, b = {b}, c = {c}, and d = {d}");

            //combined operators
            // a = a + 1
            a = a + 1;
            b += 1; // b = b + 1

            Console.WriteLine($"a = {a}");

            a += 3;
            Console.WriteLine($"a = {a}");

            Console.WriteLine($"b = {b}");

            b -= 6;
            Console.WriteLine($"b = {b}");

            c = c % d;
            Console.WriteLine($"c = {c}");

            e = e % f;
            Console.WriteLine($"e = {e}");

            c *= d;
            Console.WriteLine($"c = {c}");

            //c++; // use then increment
            Console.WriteLine($"c = {c++}");

            //++a; // increment then use
            Console.WriteLine($"c = {++c}");

            // divide by zero
            Console.WriteLine($"c / 0 = {c / 0}"); // double divided by zero is infinity or NaN(Not a Number)
            //Console.WriteLine($"a / 0 = {a / 0}"); // error, int cant be divided by zero

            //keeps the console window open
            Console.ReadLine();

        }
    }
}