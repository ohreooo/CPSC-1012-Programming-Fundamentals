﻿/*
 * Purpose
 * Input
 * Output
 * Author
 * Date
 */

namespace ArithmeticProblems4String
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //declare variables
            string inputNumber;
            //int convertedString;
            int digit1,
                digit2,
                digit3,
                sum;

            //input variables
            Console.Write("Enter a 3 digit whole number: ");
            inputNumber = Console.ReadLine();

            //convertedString = int.Parse(inputNumber);

            //parsing string to int
            digit1 = int.Parse(inputNumber.Substring(0, 1));
            digit2 = int.Parse(inputNumber.Substring(1, 1));
            digit3 = int.Parse(inputNumber.Substring(2, 1));

            //adding the digits
            sum = digit1 + digit2 + digit3;

            //display the results
            Console.WriteLine($"The sum of the digits is {sum}");
            //Console.Write($"The input number was {convertedString}");
            Console.ReadLine();
        }
    }
}
