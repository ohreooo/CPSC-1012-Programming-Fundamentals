﻿/*
    Purpose: Calculate average of three real numbers

    Input: Number 1, Number 2, Number 3

    Output: Average of the Three Input Numbers

    Author: Reonel Duque

    Date: September 9, 2022
*/

namespace ArithmeticProblems
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables and constants
            double number1,
                number2,
                number3,
                average;

            // input 3 real numbers
            Console.Write("Enter the first number: ");
            number1 = double.Parse(Console.ReadLine());

            Console.Write("Enter the second number: ");
            number2= double.Parse(Console.ReadLine());

            Console.Write("Enter the third number: ");
            number3= double.Parse(Console.ReadLine());

            //calculating for average
            average = ((number1 + number2 + number3) / 3);

            //display results
            //Console.WriteLine("The average of {0}, {1}, and {2} is {3:f2}", number1, number2, number3, average);
            Console.WriteLine($"The average of {number1}, {number2}, and {number3} is {average:f2}"); // <-- called "string literals"

            //keeps the console window open
            Console.ReadLine();

        }
    }
}