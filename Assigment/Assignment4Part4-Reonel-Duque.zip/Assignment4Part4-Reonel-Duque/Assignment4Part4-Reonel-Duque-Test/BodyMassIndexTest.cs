using Assignment4Part4_Reonel_Duque;
using System;

namespace Assignment4Part4_Reonel_Duque_Test
{
    public class Tests
    {
        [Test,
        TestCase("", "Name cannot be blank"),
        TestCase(" ", "Name cannot be blank")]
        public void Name_BlankName_ThrowsException(string name, string expectedErrorMessage)
        {
            //Arrange
            int height = 60;
            int weight = 120;
            //Act
            try
            {
                BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of Name_BlankName_ThrowsException

        [Test,
        TestCase(0, "Weight must be a positive non-zero value"),
        TestCase(-100, "Weight must be a positive non-zero value")]
        public void Non_PositiveWeight_ThrowsException(double weight, string expectedErrorMessage)
        {
            //Arrange
            int height = 60;
            string name = "Reo";
            //Act
            try
            {
                BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of Non_PositiveWeight_ThrowsException

        [Test,
        TestCase(0, "Height must be a positive non-zero value"),
        TestCase(-100, "Height must be a positive non-zero value")]
        public void Non_PositiveHeight_ThrowsException(double height, string expectedErrorMessage)
        {
            //Arrange
            int weight = 120;
            string name = "Reo";
            //Act
            try
            {
                BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of Non_PositiveHeight_ThrowsException

        [Test,
        TestCase("Underweight Person1", 90, 60, 17.6, "underweight"),
        TestCase("Underweight Person2", 120, 75, 15.0, "underweight")]
        public void Bmi_Returns_Underweight_Bmi_And_Bmi_Message(string name, double weight, double height, double expectedBmi, string expectedBmiMessage)
        {
            //Arrange & Act
            BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);

            //Assert
            Assert.AreEqual(expectedBmi, bodyMass.Bmi());
            Assert.AreEqual(expectedBmiMessage, bodyMass.BmiCategory());
        }//end of Bmi_Returns_Underweight_Bmi_And_Bmi_Message

        [Test,
        TestCase("Normal weight Person1", 111, 65, 18.5, "normal"),
        TestCase("Normal weight Person2", 149, 65, 24.8, "normal")]
        public void Bmi_Returns_Normal_Bmi_And_Bmi_Message(string name, double weight, double height, double expectedBmi, string expectedBmiMessage)
        {
            //Arrange & Act
            BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);

            //Assert
            Assert.AreEqual(expectedBmi, bodyMass.Bmi());
            Assert.AreEqual(expectedBmiMessage, bodyMass.BmiCategory());
        }//end of Bmi_Returns_Normal_Bmi_And_Bmi_Message

        [Test,
        TestCase("Overweight Person1", 150, 65, 25.0, "overweight"),
        TestCase("Overweight weight Person2", 179, 65, 29.8, "overweight")]
        public void Bmi_Returns_Overweight_Bmi_And_Bmi_Message(string name, double weight, double height, double expectedBmi, string expectedBmiMessage)
        {
            //Arrange & Act
            BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);

            //Assert
            Assert.AreEqual(expectedBmi, bodyMass.Bmi());
            Assert.AreEqual(expectedBmiMessage, bodyMass.BmiCategory());
        }//end of Bmi_Returns_Overweight_Bmi_And_Bmi_Message

        [Test,
        TestCase("Obese Person1", 180, 65, 30.0, "obese"),
        TestCase("Obese weight Person2", 210, 65, 34.9, "obese")]
        public void Bmi_Returns_Obeset_Bmi_And_Bmi_Message(string name, double weight, double height, double expectedBmi, string expectedBmiMessage)
        {
            //Arrange & Act
            BodyMassIndex bodyMass = new BodyMassIndex(name, weight, height);

            //Assert
            Assert.AreEqual(expectedBmi, bodyMass.Bmi());
            Assert.AreEqual(expectedBmiMessage, bodyMass.BmiCategory());
        }//end of Bmi_Returns_Obeset_Bmi_And_Bmi_Message

    }
}