﻿/*
Purpose: write a Unit Test class to test a BodyMassIndex class coded by someone else. You will
then fix all the errors in the existing BodyMassIndex class until all the test cases pass
Inputs: TestCases
Outputs: Success
Written by: Reonel Duque
Written for: Allan Anderson
Section No: A02
Last modified: December 12, 2022
*/
namespace Assignment4Part4_Reonel_Duque
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}