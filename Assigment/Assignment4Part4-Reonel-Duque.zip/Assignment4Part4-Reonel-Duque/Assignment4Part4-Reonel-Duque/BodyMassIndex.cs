﻿

namespace Assignment4Part4_Reonel_Duque
{
    public class BodyMassIndex
    {
        private string _name;
        private double _weight;
        private double _height;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                /*
                if (string.IsNullOrWhiteSpace(value))
                {
                    _name = value;
                }
                else
                {
                    throw new Exception("Name cannot be blank");
                }*/
                //the statements within the if else statements should have been reversed since the if statements check for the error of blank or whitespace
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("Name cannot be blank");
                }
                else
                {
                    _name = value;
                }
            }
        }
        public double Weight
        {
            get
            {
                //return _height;
                // it should be _weight
                return _weight;
            }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("Weight must be a positive non-zero value");
                }
                //Height = value;
                //it should be the private member _weight and the assignment of the value to it should be inside the else statement
                else
                {
                    _weight = value;
                }
            }
        }
        public double Height
        {
            get
            {
                //return Height
                //it should be the private member field _height
                return _height;
            }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("Height must be a positive non-zero value");
                }
                //_height = value;
                //it should have been inside an else statement
                else
                {
                    _height = value;
                }
 
            }
        }

        //missing default constructor
        public BodyMassIndex()
        {
            Name = "Joe";
            Weight = 149;
            Height = 65;
        }
        public BodyMassIndex(string name, double weight, double height)
        {
            /*
            name = name;
            this.Weight = weight;
            height = this.Height;
             */
            // the variables should be assigned to the public properties of the class
            Name = name;
            Weight = weight;
            Height = height;
        }


        // <summary>
        // Calculate the body mass index (BMI) using the weight and height of the person.
        ///
        /// The BMI of a person is calculated using the formula: BMI = 700 * weight /(height* height)
        /// where weight is in pounds and height is in inches.
        /// </summary>
        /// <returns>the body mass index (BMI) value of the person</returns>
        public double Bmi()
        {
            //double bmiValue = 703 * Weight / Math.Pow(2, Height)
            // it should have been Math.Pow(Height, 2) since the exponent is 2 and the base is Height
            double bmiValue = ((703 * Weight) / (Math.Pow(Height, 2)));
            bmiValue = Math.Round(bmiValue, 1);
            return bmiValue;
        }
        /// <summary>
        /// Determines the BMI Category of the person using their BMI value.
        /// </summary>
        /// <returns>one of following: underweight, normal, overweight, obese.</returns>
        public string BmiCategory()
        {
            string category = "Unknown";
            double bmiValue = Bmi();

            /*
            if (bmiValue < 18.5)
                {
                category = "underweight";
                }
                if (bmiValue < 24.9)
                {
                category = "normal";
                }
                if (bmiValue < 29.9)
                {
                category = "overweight";
                }
                if (bmiValue >= 30)
                {
                category = "obese";
                }
            */

            //multiple ways to fix it, an else if statement would prevent it from going through the other conditions once the conditions have been met
            //the other fix is to put another condition in the if statements
            //I chose to do both for redundancy
            if (bmiValue < 18.5)
            {
                category = "underweight";
            }
            else if (bmiValue <= 24.9 && bmiValue >= 18.5)
            {
                category = "normal";
            }
            else if (bmiValue <= 29.9 && bmiValue >= 25.0)
            {
                category = "overweight";
            }
            else if (bmiValue >= 30)
            {
                category = "obese";
            }
            return category;
        }
    }
}
