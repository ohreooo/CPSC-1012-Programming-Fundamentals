using Assignment4Part3_ReonelDuque;
using NUnit.Framework;
using System;
using System.ComponentModel.DataAnnotations;

namespace Assignment4Part3_ReonelDuque_Test
{
    /*
 * https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices
 *
 * Naming your tests
 * The name of your test should consist of three parts:
 * - The name of the method being tested.
 * - The scenario under which it's being tested.
 * - The expected behavior when the scenario is invoked.
 *
 * Arrange, Act, Assert is a common pattern when unit testing. As the name implies, it
 consists of three main actions:
 * - Arrange your objects, create, and set them up as necessary.
 * - Act on an object.
 * - Assert that something is as expected.
 *
 */
    public class PersonTest
    {
        [Test,
        TestCase("", "Name cannot be blank"),
        TestCase(" ", "Name cannot be blank")]
        public void Name_BlankName_ThrowsException(string name, string expectedErrorMessage)
        {
            //Arrange
            DateTime today = DateTime.Today;
            //Act
            try
            {
                Person currentPerson = new Person(name, today);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of Name_BlankName_ThrowsException

        [Test,
        TestCase("U", "Name must contain 5 or more characters"),
        TestCase("Un", "Name must contain 5 or more characters"),
        TestCase("Unc", "Name must contain 5 or more characters"),
        TestCase("Uncl", "Name must contain 5 or more characters")]
        public void Name_MinimumNameLength_ThrowsException(string name, string expectedErrorMessage)
        {
            //Arrange
            DateTime today = DateTime.Today;

            //Act
            try
            {
                Person currentPerson = new Person(name, today);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of Name_MinimumNameLength_ThrowsException

        [Test,
        TestCase("2022-12-25", "BirthDate cannot be in the future"),
        TestCase("2023-01-09", "BirthDate cannot be in the future")]
        public void BirthDate_FutureDate_ThrowsException(string birthDateString, string expectedErrorMessage)
        {
            // Arrange
            string name = "Uncle Bob";
            DateTime birthDate = DateTime.Parse(birthDateString);
            // Act
            try
            {
                Person currentPerson = new Person(name, birthDate);
                Assert.Fail("An exception should have been thrown");
            }
            catch (Exception ex)
            {
                // Assert
                StringAssert.Contains(ex.Message, expectedErrorMessage);
            }
        }//end of BirthDate_FutureDate_ThrowsException

        [Test,
        TestCase("Queen Elizabeth II", "1926-04-21", 96),
        TestCase("King Charles III", "1948-11-14", 74),
        TestCase("Prince William of Wales", "1982-06-21", 40),
        TestCase("Prince George of Wales", "2013-07-22", 9)]
        //TestCase("Uncle Bob", "1952-12-05", 69) // uncomment if running test before Dec 5
        public void CurrentAge_KnownAge_ReturnsAge(string name, string birthDateString, int expectedAge)
        {
            // Arrange and Act
            DateTime birthDate = DateTime.Parse(birthDateString);
            Person currentPerson = new Person(name, birthDate);
            // Assert
            Assert.AreEqual(expectedAge, currentPerson.CurrentAge);
        }//end of CurrentAge_KnownAge_ReturnsAge

        [Test,
        TestCase("Queen Elizabeth II", "1926-04-21", "2022-09-08", 96),
        TestCase("King Charles III", "1948-11-14", "2022-09-08", 73),
        TestCase("Uncle Bob", "1952-12-05", "2022-12-15", 70)]

        public void AgeOn_FutureDate_ReturnsAge(string name, string birthDateString, string onDateString, int expectedAge)
        {
            // Arrange and Act
            DateTime birthDate = DateTime.Parse(birthDateString);
            DateTime onDate = DateTime.Parse(onDateString);
            Person currentPerson = new Person(name, birthDate);
            // Assert
            Assert.AreEqual(expectedAge, currentPerson.AgeOn(onDate));
        }//end of AgeOn_FutureDate_ReturnsAge

        [Test,
        TestCase("1900-01-01", "Rat"),
        TestCase("1901-01-01", "Ox"),
        TestCase("1902-01-01", "Tiger"),
        TestCase("1903-01-01", "Rabbit"),
        TestCase("1904-01-01", "Dragon"),
        TestCase("1905-01-01", "Snake"),
        TestCase("1906-01-01", "Horse"),
        TestCase("1907-01-01", "Sheep"),
        TestCase("1908-01-01", "Monkey"),
        TestCase("1909-01-01", "Rooster"),
        TestCase("1910-01-01", "Dog"),
        TestCase("1911-01-01", "Pig")]
        public void ChineseZodiac_YearsForAllAnimals_ReturnsAnimal(string birthDateString, string expectedChineseZodiac)
        {
            // Arrange and Act
            DateTime birthDate = DateTime.Parse(birthDateString);
            Person currentPerson = new Person("Chinese Zodiac", birthDate);
            // Assert
            Assert.AreEqual(expectedChineseZodiac.ToUpper(), currentPerson.ChineseZodiac().ToUpper());
        }//end of ChineseZodiac_YearsForAllAnimals_ReturnsAnimal

        [Test,
        TestCase("1900-03-21", "Aries"),
        TestCase("1900-04-19", "Aries"),
        TestCase("1900-04-20", "Taurus"),
        TestCase("1900-05-20", "Taurus"),
        TestCase("1900-05-21", "Gemini"),
        TestCase("1900-06-21", "Gemini"),
        TestCase("1900-06-22", "Cancer"),
        TestCase("1900-07-22", "Cancer"),
        TestCase("1900-07-23", "Leo"),
        TestCase("1900-08-22", "Leo"),
        TestCase("1900-08-23", "Virgo"),
        TestCase("1900-09-22", "Virgo"),
        TestCase("1900-09-23", "Libra"),
        TestCase("1900-10-22", "Libra"),
        TestCase("1900-10-23", "Scorpio"),
        TestCase("1900-11-22", "Scorpio"),
        TestCase("1900-11-23", "Sagittarius"),
        TestCase("1900-12-21", "Sagittarius"),
        TestCase("1900-12-22", "Capricorn"),
        TestCase("1900-01-19", "Capricorn"),
        TestCase("1900-01-20", "Aquarius"),
        TestCase("1900-02-18", "Aquarius"),
        TestCase("1900-02-19", "Pisces"),
        TestCase("1900-03-20", "Pisces")]
        public void AstrologicalSign_AllSignDateRanges_ReturnSign(string birthDateString, string expectedAstrologicalSign)
        {
            // Arrange and Act
            DateTime birthDate = DateTime.Parse(birthDateString);
            Person currentPerson = new Person("Astrological Sign", birthDate);
            // Assert
            Assert.AreEqual(expectedAstrologicalSign.ToUpper(), currentPerson.AstrologicalSign().ToUpper());
        }//end of AstrologicalSign_AllSignDateRanges_ReturnSign
    }
}

