﻿/*
Purpose: Write class to model a Person that uses the person’s birth date to determine their
current age, the age on a specific date, their Chinese Zodiac animal, and their Astrological sign.
Inputs: TestCases
Outputs: Success
Written by: Reonel Duque
Written for: Allan Anderson
Section No: A02
Last modified: December 5, 2022
*/
namespace Assignment4Part3_ReonelDuque
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}