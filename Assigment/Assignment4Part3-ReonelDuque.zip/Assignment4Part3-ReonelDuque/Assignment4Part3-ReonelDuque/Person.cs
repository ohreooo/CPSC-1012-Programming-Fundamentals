﻿

namespace Assignment4Part3_ReonelDuque
{
    public class Person
    {
        //private member fields
        private string _name;
        private DateTime _birthDate;

        //public member fields
        public string Name
        {
            get { return _name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("Name cannot be blank");
                }
                else if (value.Length < 5)
                {
                    throw new Exception("Name must contain 5 or more characters");
                }
                else
                {
                    _name = value;
                }
            }
        }//end of Name

        public DateTime BirthDate
        {
            get { return _birthDate; }
            set
            {
                DateTime today = DateTime.Now;
                if (today.Date < value.Date)
                {
                    throw new Exception("BirthDate cannot be in the future");
                }
                else
                {
                    _birthDate = value;
                }
            }
        }//end of BirthDate

        //public read-file only
        public int CurrentAge
        {
            get { return (int)(((DateTime.Now - BirthDate).TotalDays)/365.242199); }
        }//end of CurrentAge

        //Greedy Constructor
        public Person(string name, DateTime birthDate)
        {
            Name = name;
            BirthDate = birthDate;
        }//end of Person

        public int AgeOn(DateTime onDate)
        {
            return (int)(((onDate - BirthDate).TotalDays) / 365.242199);
        }//end of AgeOn

        public string ChineseZodiac()
        {
            string zodiac;
            int sign = BirthDate.Year % 12;
            switch(sign)
            {
                case 1:
                    zodiac = "Rooster";
                    break;
                case 2:
                    zodiac = "Dog";
                    break;
                case 3:
                    zodiac = "Pig";
                    break;
                case 4:
                    zodiac = "Rat";
                    break;
                case 5:
                    zodiac = "Ox";
                    break;
                case 6:
                    zodiac = "Tiger";
                    break;
                case 7:
                    zodiac = "Rabbit";
                    break;
                case 8:
                    zodiac = "Dragon";
                    break;
                case 9:
                    zodiac = "Snake";
                    break;
                case 10:
                    zodiac = "Horse";
                    break;
                case 11:
                    zodiac = "Sheep";
                    break;
                default:
                    zodiac = "Monkey";
                    break;
            }
            return zodiac;
        }//end of ChineseZodiac

        public string AstrologicalSign()
        {
            string astro;
            int month = BirthDate.Month,
                day = BirthDate.Day;
            if ((day >= 21 && month ==3) || (day <= 19 && month == 4))
            {
                astro = "Aries";
            }
            else if ((day >= 20 && month == 4) || (day <= 20 && month == 5))
            {
                astro = "Taurus";
            }
            else if ((day >= 21 && month == 5) || (day <= 21 && month == 6))
            {
                astro = "Gemini";
            }
            else if ((day >= 22 && month == 6) || (day <= 22 && month == 7))
            {
                astro = "Cancer";
            }
            else if ((day >= 23 && month == 7) || (day <= 22 && month == 8))
            {
                astro = "Leo";
            }
            else if ((day >= 23 && month == 8) || (day <= 22 && month == 9))
            {
                astro = "Virgo";
            }
            else if ((day >= 23 && month == 9) || (day <= 22 && month == 10))
            {
                astro = "Libra";
            }
            else if ((day >= 23 && month == 10) || (day <= 22 && month == 11))
            {
                astro = "Scorpio";
            }
            else if ((day >= 23 && month == 11) || (day <= 21 && month == 12))
            {
                astro = "Sagittarius";
            }
            else if ((day >= 22 && month == 12) || (day <= 19 && month == 1))
            {
                astro = "Capricorn";
            }
            else if ((day >= 20 && month == 1) || (day <= 18 && month == 2))
            {
                astro = "Aquarius";
            }
            else
            {
                astro = "Pisces";
            }
            return astro;
        }//end of AstrologicalSign
    }
}
